﻿param(
    [int]$Epochs = 60,
    [string]$RunName = 'rnn_001',
    [string]$Distribution = 'Ubuntu-24.04',
    [ValidateSet('auto', 'cpu', 'cuda')][string]$Device = 'cuda',
    [switch]$Resume,
    [switch]$PrepareOnly
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Invoke-WslChecked {
    param([string[]]$WslArguments, [string]$FailureMessage, [string]$LogPath)
    $previousPreference = $ErrorActionPreference
    try {
        # Windows PowerShell 5.1 can turn native stderr into NativeCommandError.
        # Preserve the text, and determine success from the actual process exit code.
        $ErrorActionPreference = 'Continue'
        if ($LogPath) {
            & wsl.exe @WslArguments 2>&1 | ForEach-Object { $_.ToString() } |
                Tee-Object -FilePath $LogPath -Append -ErrorAction Stop
        } else {
            & wsl.exe @WslArguments 2>&1 | ForEach-Object { $_.ToString() }
        }
        $processExitCode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $previousPreference
    }
    if ($processExitCode -ne 0) { throw ($FailureMessage + " (exit code: $processExitCode)") }
}

if ($RunName -notmatch '^[a-zA-Z0-9_-]+$') { throw 'RunName 只能包含字母、数字、下划线和横线。' }
if ($Epochs -lt 1) { throw 'Epochs 必须为正数。' }
$projectPath = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$linuxProject = '/mnt/' + $projectPath.Substring(0, 1).ToLowerInvariant() + $projectPath.Substring(2).Replace('\', '/')
$linuxOutput = '/home/qd/asr_learning/' + $RunName
$localResults = Join-Path $projectPath ('runs/' + $RunName)
New-Item -ItemType Directory -Path $localResults -Force | Out-Null
$pythonPath = '/home/qd/.venvs/wenet/bin/python'
Invoke-WslChecked -WslArguments @('-d', $Distribution, '--', $pythonPath, ($linuxProject + '/test_core.py')) `
    -FailureMessage '模型核心检查失败，尚未启动训练。'
$arguments = @('-d', $Distribution, '--', $pythonPath, '-u', ($linuxProject + '/train.py'),
               '--output', $linuxOutput, '--epochs', [string]$Epochs, '--device', $Device)
if ($Resume) { $arguments += '--resume' }
if ($PrepareOnly) { $arguments += '--prepare-only' }
Invoke-WslChecked -WslArguments $arguments -LogPath (Join-Path $localResults 'console.log') `
    -FailureMessage '实验运行失败，请查看控制台和 console.log。未把失败当作完成。'
if (-not $PrepareOnly) {
    # 音频、特征缓存和训练检查点保留在 E 盘承载的 WSL 文件系统。
    # Windows 只镜像小型报告和识别结果，不复制整份数据集。
    $reportFiles = @('experiment_report.html', 'summary.json', 'history.csv', 'history.json',
                    'config.json', 'environment.json', 'data_statistics.json', 'vocab.json',
                    'predictions_train.json', 'predictions_dev.json', 'predictions_test.json', 'status.json')
    $linuxLocal = $linuxProject + '/runs/' + $RunName
    foreach ($name in $reportFiles) {
        Invoke-WslChecked -WslArguments @('-d', $Distribution, '--', 'cp', ($linuxOutput + '/' + $name), ($linuxLocal + '/' + $name)) `
            -FailureMessage ('复制报告失败：' + $name)
    }
    Write-Host ('报告：' + (Join-Path $localResults 'experiment_report.html'))
}

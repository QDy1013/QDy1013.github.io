"""检查真实容易出错的边界：补齐帧、文字错位、因果关系和梯度连接。"""
import json
from pathlib import Path
import unittest

import torch
from torch import nn
from torch.nn import functional as F

from data import BOS, EOS, PAD, collate, ids_to_text
from metrics import edit_distance, summarize
from model import RNNEncoderDecoder


class CoreChecks(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.config = json.loads(Path(__file__).with_name("config.json").read_text(encoding="utf-8"))
        self.config.update(hidden_size=12, embedding_size=8, num_layers=1)
        self.model = RNNEncoderDecoder(self.config, 9).eval()

    def test_padding_cannot_change_encoder_summary(self):
        features = torch.randn(2, 13, 80)
        lengths = torch.tensor([13, 5])
        original = self.model.encode(features, lengths)[0]
        features[1, 5:] = 999
        changed = self.model.encode(features, lengths)[0]
        torch.testing.assert_close(original, changed)
        alone = self.model.encode(features[1:2, :5], torch.tensor([5]))[0]
        torch.testing.assert_close(original[1:2], alone)

    def test_future_text_cannot_change_previous_logits(self):
        features, lengths = torch.randn(1, 11, 80), torch.tensor([11])
        a = torch.tensor([[BOS, 4, 5, 6]])
        b = torch.tensor([[BOS, 4, 8, 7]])
        out_a = self.model(features, lengths, a)
        out_b = self.model(features, lengths, b)
        torch.testing.assert_close(out_a[:, :2], out_b[:, :2])

    def test_teacher_forcing_shift_and_padding(self):
        samples = [{"features": torch.ones(5, 80), "tokens": [4, 5]},
                   {"features": torch.ones(3, 80), "tokens": [6]}]
        batch = collate(samples)
        self.assertEqual(batch["decoder_inputs"].tolist(), [[BOS, 4, 5], [BOS, 6, PAD]])
        self.assertEqual(batch["targets"].tolist(), [[4, 5, EOS], [6, EOS, PAD]])

    def test_only_plain_rnn_cells(self):
        modules = list(self.model.modules())
        self.assertEqual(sum(isinstance(m, nn.RNN) for m in modules), 2)
        self.assertFalse(any(isinstance(m, (nn.LSTM, nn.GRU, nn.MultiheadAttention)) for m in modules))

    def test_loss_reaches_encoder_and_decoder(self):
        batch = collate([{"features": torch.randn(9, 80), "tokens": [4, 5]}])
        logits = self.model(batch["features"], batch["lengths"], batch["decoder_inputs"])
        loss = F.cross_entropy(logits.flatten(0, 1), batch["targets"].flatten(), ignore_index=PAD)
        loss.backward()
        for module in [self.model.encoder, self.model.decoder]:
            self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in module.parameters()))
            self.assertGreater(sum(p.grad.abs().sum().item() for p in module.parameters()), 0)

    def test_cer_and_special_tokens(self):
        self.assertEqual(edit_distance("你好", "您好"), 1)
        self.assertEqual(edit_distance("", "你好"), 2)
        self.assertEqual(edit_distance("哈哈", "哈"), 1)
        self.assertEqual(summarize([{"reference": "你", "prediction": "你好呀", "edits": 2}])["cer"], 2)
        self.assertEqual(ids_to_text([BOS, 4, 3, EOS, 5], ["p", "b", "e", "u", "你", "好"]), "你□")


if __name__ == "__main__":
    unittest.main(verbosity=2)

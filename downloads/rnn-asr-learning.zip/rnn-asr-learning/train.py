"""运行 RNN、LSTM 固定向量或 LSTM 注意力实验，使用 AISHELL 原始划分。"""
from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import random
import time

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import numpy as np
import torch
from torch.nn import functional as F
from torch.utils.data import DataLoader

from data import PAD, SpeechDataset, collate, collate_sorted, ids_to_text, prepare_dataset
from metrics import edit_distance, summarize
from models import build_model
from report import write_report
from training_steps import train_step  # 支持保持有效batch不变的显存小批次计算。


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def loader(samples, batch_size, shuffle=False, data=None, config=None):
    data, config = data or {}, config or {}
    workers = config.get("num_workers", 0)
    augment = config.get("spec_augment") if shuffle else None  # 只有打乱顺序的训练loader做SpecAugment；验证、测试和训练探针都不遮挡。
    return DataLoader(SpeechDataset(samples, data.get("cmvn_mean"), data.get("cmvn_std"), augment),
                      batch_size=batch_size, shuffle=shuffle,
                      collate_fn=collate_sorted if shuffle and config.get("sort_within_batch", False) else collate,  # 只在当前训练有效batch内部按长度排列。
                      num_workers=workers, persistent_workers=workers > 0,
                      pin_memory=config.get("pin_memory", False),
                      **({"multiprocessing_context": "spawn",
                          "prefetch_factor": config.get("prefetch_factor", 2)} if workers else {}))


@torch.no_grad()
def evaluate(model, samples, vocab, device, config, data=None):
    if config.get("model_type") in {"lstm_attention_ctc", "transformer_ctc"}:  # 联合模型同时记录Attention和CTC自由识别结果。
        from evaluation_ctc import evaluate_joint  # 不改变原来三种模型的评测公式。
        return evaluate_joint(model, samples, vocab, device, config, data, loader)  # 主指标仍是Attention CER。
    model.eval()
    rows = []
    total_loss, tokens = 0.0, 0
    for batch in loader(samples, config.get("eval_batch_size", config["batch_size"]), data=data, config=config):
        features = batch["features"].to(device, non_blocking=config.get("pin_memory", False))
        logits = model(features, batch["lengths"], batch["decoder_inputs"].to(device, non_blocking=config.get("pin_memory", False)))
        targets = batch["targets"].to(device, non_blocking=config.get("pin_memory", False))
        total_loss += F.cross_entropy(logits.reshape(-1, len(vocab)), targets.reshape(-1),
                                     ignore_index=PAD, reduction="sum").item()
        tokens += targets.ne(PAD).sum().item()
        # 真正的识别只使用声音，不给模型传参考文字。
        predictions = model.greedy_decode(features, batch["lengths"], config["max_decode_steps"])
        for sample, predicted in zip(batch["samples"], predictions):
            text = ids_to_text(predicted, vocab)
            rows.append({"id": sample["id"], "wav": sample["wav"], "reference": sample["text"],
                         "prediction": text, "edits": edit_distance(sample["text"], text),
                         "unknown_reference_characters": sample["tokens"].count(3)})
    metrics = summarize(rows)
    metrics["loss"] = total_loss/max(1, tokens)
    return metrics, rows


def build_scheduler(optimizer, config):  # 按配置创建学习率调度；旧配置没有lr_schedule时返回None，学习率固定不变。
    setting = config.get("lr_schedule")  # 例如{"type": "noam", "warmup_steps": 1500}。
    if not setting:  # 旧实验：固定学习率。
        return None  # 训练循环据此跳过调度。
    if setting["type"] != "noam":  # 目前只实现Noam，避免拼错类型时悄悄用了固定学习率。
        raise ValueError(f"未知的学习率调度类型：{setting['type']}")  # 明确报错。
    warmup = setting["warmup_steps"]  # warmup步数，按参数更新次数计（每个有效batch一次）。
    if warmup <= 0:  # 防止除零。
        raise ValueError("warmup_steps必须为正。")  # 明确报错。

    def noam(step):  # 返回“峰值学习率的倍数”；LambdaLR用它乘config["learning_rate"]。
        step = step + 1  # LambdaLR从0开始计数；第1次更新对应step=1，避免0次方根。
        return min(step / warmup, (warmup / step) ** 0.5)  # 前warmup步线性升到1，之后按步数的-0.5次方下降。

    return torch.optim.lr_scheduler.LambdaLR(optimizer, noam)  # 构造时即把学习率设为峰值×noam(0)。


def checkpoint_payload(model, optimizer, epoch, config, data, history, best_key, best_epoch, scheduler=None):
    return {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict() if scheduler is not None else None,  # 调度器已走过的步数；不存的话续训会重新warmup。
            "epoch": epoch, "config": config, "vocab": data["vocab"],
            "cmvn_mean": data["cmvn_mean"], "cmvn_std": data["cmvn_std"],
            "data_signature": data["signature"], "history": history,
            "best_key": best_key, "best_epoch": best_epoch,
            "python_rng": random.getstate(), "numpy_rng": np.random.get_state(),
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path(__file__).with_name("config.json"))
    parser.add_argument("--output", type=Path, default=Path("/home/qd/asr_learning/rnn_001"))
    parser.add_argument("--data-dir")
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--train-size", type=int)
    parser.add_argument("--dev-size", type=int)
    parser.add_argument("--test-size", type=int)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--eval-only", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding="utf-8"))
    for key in ["data_dir", "epochs", "train_size", "dev_size", "test_size"]:
        value = getattr(args, key)
        if value is not None:
            config[key] = value
    for key in ["epochs", "batch_size", "stack_frames"]:
        if config[key] <= 0:
            parser.error(f"{key} must be positive")
    for key in ["micro_batch_size", "eval_batch_size"]:
        if config.get(key, 1) <= 0:
            parser.error(f"{key} must be positive")
    if not 0 < config.get("cuda_memory_fraction", 1.0) <= 1:
        parser.error("cuda_memory_fraction must be in (0, 1]")
    if config.get("model_type") in {"lstm_attention_ctc", "transformer_ctc"} and not 0 < config.get("ctc_weight", 0) < 1:  # 联合训练两种损失都须参与。
        parser.error("ctc_weight must be in (0, 1)")  # 拒绝误配。
    for key in ["train_size", "dev_size", "test_size"]:
        if config[key] < 0:
            parser.error(f"{key} must be nonnegative (0 means all utterances)")
    if config.get("feature_storage", "memory") not in {"memory", "disk"}:
        parser.error("feature_storage must be memory or disk")
    output = args.output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    # 大数据准备也保存实际配置，便于进程运行中查看。
    if (output / "last.pt").is_file() and not (args.resume or args.eval_only or args.prepare_only):
        parser.error("该目录已有训练结果。请用 --resume 继续，或指定新 --output，保留旧实验。")
    torch.set_num_threads(config["cpu_threads"])
    seed_everything(config["seed"])
    device = torch.device("cuda" if args.device == "auto" and torch.cuda.is_available()
                          else "cpu" if args.device == "auto" else args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("要求 CUDA，但当前环境看不到 GPU。")
    if device.type == "cuda" and "cuda_memory_fraction" in config:
        torch.cuda.set_per_process_memory_fraction(config["cuda_memory_fraction"])
    write_json(output / "requested_config.json", config)
    data = prepare_dataset(config, output)
    if args.prepare_only:
        print(json.dumps(data["statistics"], ensure_ascii=False, indent=2), flush=True)
        return
    model = build_model(config, len(data["vocab"])).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config["learning_rate"])
    scheduler = build_scheduler(optimizer, config)  # 有lr_schedule时，learning_rate表示峰值学习率。
    history, best_key, best_epoch, start = [], (float("inf"), float("inf")), 0, 1
    if config.get("warm_start_checkpoint") and not (args.resume or args.eval_only):  # 新实验第一轮前只导入旧模型权重。
        from warm_start_ctc import initialize_from_attention  # 新CTC层仍为随机初始化。
        provenance = initialize_from_attention(model, config, data)  # 核对结构、词表、数据及归一化。
        write_json(output / "initialization.json", provenance)  # 明确源轮次及新Adam状态。
        torch.save(checkpoint_payload(model, optimizer, 0, config, data, [], best_key, 0), output / "initial.pt")  # 保留精确的新阶段起点。
        print("WARM_START: " + json.dumps(provenance, ensure_ascii=False), flush=True)  # 实时日志也能追溯来源。
    if args.eval_only and (output / "history.json").is_file():
        history = json.loads((output / "history.json").read_text(encoding="utf-8"))
    if args.resume:
        previous = torch.load(output / "last.pt", map_location=device, weights_only=False)
        if previous["config"].get("model_type", "rnn") != config.get("model_type", "rnn"):
            raise ValueError("检查点与配置的模型类型不同，请使用对应的独立实验目录。")
        for key in ["hidden_size", "embedding_size", "num_layers", "stack_frames",
                    "d_model", "num_heads", "ffn_size", "encoder_layers", "decoder_layers"]:  # 后五项是Transformer的结构设置。
            if previous["config"].get(key) != config.get(key):  # 某种模型没有的项两边都是None，视为一致。
                raise ValueError(f"恢复训练时结构设置 {key} 不一致。")
        if previous["data_signature"] != data["signature"]:
            raise ValueError("恢复训练时数据划分发生改变。")
        model.load_state_dict(previous["model"])
        optimizer.load_state_dict(previous["optimizer"])
        if scheduler is not None:  # 本实验使用学习率调度。
            if previous.get("scheduler") is None:  # 检查点里没有调度状态，续训的学习率会对不上。
                raise ValueError("配置要求学习率调度，但检查点没有保存调度器状态。")  # 不悄悄从头warmup。
            scheduler.load_state_dict(previous["scheduler"])  # 恢复已走过的步数和当前学习率。
        start = previous["epoch"]+1
        history, best_key, best_epoch = previous["history"], previous["best_key"], previous["best_epoch"]
        random.setstate(previous["python_rng"])
        np.random.set_state(previous["numpy_rng"])
        torch.set_rng_state(previous["torch_rng"].cpu())
        if device.type == "cuda" and previous["cuda_rng"]:
            torch.cuda.set_rng_state_all([state.cpu() for state in previous["cuda_rng"]])
        del previous  # 模型、优化器和随机状态已恢复，释放重复的检查点张量。

    environment = {"torch": torch.__version__, "torchaudio": __import__("torchaudio").__version__,
                   "device": str(device),
                   "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else None,
                   "parameters": sum(p.numel() for p in model.parameters()),
                   "vocab_size": len(data["vocab"]), "architecture":
                   {"lstm": "LSTM, fixed context, no attention",
                    "lstm_attention": "LSTM, global scaled general attention, no input feeding, no CTC",
                    "lstm_attention_ctc": "LSTM shared encoder, global attention decoder and CTC head, joint training",  # 第四阶段。
                    "transformer_ctc": "Transformer encoder, Transformer attention decoder and CTC head, joint training",  # 第五阶段：结构对照。
                    "rnn": "vanilla RNN, fixed context, no attention"}[config.get("model_type", "rnn")]}
    write_json(output / "config.json", config)
    write_json(output / "environment.json", environment)
    print(json.dumps(environment, ensure_ascii=False), flush=True)
    run_start = time.perf_counter()
    write_json(output / "status.json", {"status": "running", "mode": "evaluation" if args.eval_only else "training"})
    if not args.eval_only:
        training_loader = loader(data["splits"]["train"], config["batch_size"], True, data, config)
        for epoch in range(start, config["epochs"]+1):
            began = time.perf_counter()
            model.train()
            total_loss, total_tokens = 0.0, 0
            attention_total = ctc_total = 0.0  # 联合模型分别统计两种损失。
            ctc_characters = 0  # CTC分母不包含EOS。
            data_wait_seconds = step_seconds = transfer_seconds = gpu_compute_seconds = 0.0
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats(device)
            epoch_batches = len(training_loader)
            waiting_since = time.perf_counter()
            for step, batch in enumerate(training_loader, 1):
                data_wait_seconds += time.perf_counter() - waiting_since
                stats = train_step(model, optimizer, batch, device, config, len(data["vocab"]))
                if scheduler is not None:  # 每个有效batch只更新一次参数，所以调度也只走一步（不是每个小批次走一步）。
                    scheduler.step()  # 计算下一次更新要用的学习率。
                total_loss += stats["loss_sum"]
                total_tokens += stats["tokens"]
                if "ctc_loss_sum" in stats:  # 旧模型不进入此分支。
                    attention_total += stats["attention_loss_sum"]  # 保留Attention损失总和。
                    ctc_total += stats["ctc_loss_sum"]  # 保留CTC损失总和。
                    ctc_characters += stats["ctc_characters"]  # 累加真实字数。
                    total_loss = (1-config["ctc_weight"]) * attention_total + config["ctc_weight"] * ctc_total / ctc_characters * total_tokens  # 整轮统一归一化。
                step_seconds += stats["step_seconds"]
                transfer_seconds += stats["transfer_seconds"]
                gpu_compute_seconds += stats["gpu_compute_seconds"]
                if step % config.get("log_every_steps", 1000000) == 0:
                    progress = {"status": "training", "epoch": epoch, "epochs": config["epochs"],
                                "step": step, "steps_per_epoch": epoch_batches,
                                "train_loss_so_far": total_loss/total_tokens,
                                "elapsed_epoch_seconds": time.perf_counter()-began,
                                "micro_batch_size": config.get("micro_batch_size", config["batch_size"]),
                                "data_wait_seconds": data_wait_seconds, "step_seconds": step_seconds,
                                "gpu_compute_seconds": gpu_compute_seconds,
                                "learning_rate": optimizer.param_groups[0]["lr"]}  # 实时查看调度是否按预期在走。
                    write_json(output / "status.json", progress)
                    print(f"epoch={epoch:03d} step={step}/{epoch_batches} "
                          f"train_loss={progress['train_loss_so_far']:.4f} "
                          f"elapsed={progress['elapsed_epoch_seconds']:.1f}s", flush=True)
                waiting_since = time.perf_counter()
            if device.type == "cuda":
                torch.cuda.synchronize()
            record = {"epoch": epoch, "train_loss": total_loss/total_tokens,
                      "learning_rate": optimizer.param_groups[0]["lr"],  # 本轮结束时（下一次更新将用）的学习率。
                      "train_seconds": time.perf_counter()-began,
                      "dev_loss": None, "dev_cer": None, "train_probe_cer": None,
                      "data_wait_seconds": data_wait_seconds, "step_seconds": step_seconds,
                      "transfer_seconds": transfer_seconds, "gpu_compute_seconds": gpu_compute_seconds,
                      "peak_allocated_MiB": torch.cuda.max_memory_allocated(device)/1024**2 if device.type == "cuda" else 0,
                      "peak_reserved_MiB": torch.cuda.max_memory_reserved(device)/1024**2 if device.type == "cuda" else 0}
            print(f"timing epoch={epoch:03d} data_wait={data_wait_seconds:.2f}s "
                  f"steps={step_seconds:.2f}s gpu={gpu_compute_seconds:.2f}s "
                  f"peak_reserved={record['peak_reserved_MiB']:.0f}MiB", flush=True)
            if ctc_characters:  # 将两部分损失独立记录，便于理解CTC支路的学习。
                record.update(train_attention_loss=attention_total/total_tokens, train_ctc_loss=ctc_total/ctc_characters)  # 各自使用正确分母。
                print(f"joint epoch={epoch:03d} attention_loss={record['train_attention_loss']:.4f} ctc_loss={record['train_ctc_loss']:.4f}", flush=True)  # 在实时窗口显示。
            if epoch == 1 or epoch % config["evaluate_every"] == 0 or epoch == config["epochs"]:
                evaluation_began = time.perf_counter()  # 区分训练耗时与完整验证耗时。
                write_json(output / "status.json", {"status": "evaluating", "epoch": epoch, "epochs": config["epochs"], "train_seconds": record["train_seconds"]})  # 不把验证阶段误认为训练卡住。
                dev, _ = evaluate(model, data["splits"]["dev"], data["vocab"], device, config, data)
                probe, _ = evaluate(model, data["splits"]["train"][:config["train_probe_size"]],
                                    data["vocab"], device, config, data)
                record.update(dev_loss=dev["loss"], dev_cer=dev["cer"], train_probe_cer=probe["cer"])
                record["evaluation_seconds"] = time.perf_counter() - evaluation_began  # 包含完整dev和固定训练探针。
                if "ctc_cer" in dev:  # 同时保留CTC指标，但不把它与Attention结果混为一谈。
                    record.update(dev_ctc_cer=dev["ctc_cer"], dev_attention_loss=dev["attention_loss"], dev_ctc_loss=dev["ctc_loss"], train_probe_ctc_cer=probe["ctc_cer"])  # 固定探针不是全训练集。
                    print(f"ctc epoch={epoch:03d} dev_CTC_CER={100*dev['ctc_cer']:.2f}% train_probe_CTC_CER={100*probe['ctc_cer']:.2f}%", flush=True)  # CTC仅作独立诊断。
                candidate_key = (dev["cer"], dev["loss"])
                if candidate_key < tuple(best_key):
                    best_key, best_epoch = candidate_key, epoch
                    torch.save({"model": model.state_dict(), "config": config, "vocab": data["vocab"],
                                "cmvn_mean": data["cmvn_mean"], "cmvn_std": data["cmvn_std"],
                                "epoch": epoch, "data_signature": data["signature"]}, output / "best.pt")
                print(f"epoch={epoch:03d} train_loss={record['train_loss']:.4f} "
                      f"train_probe_CER={100*probe['cer']:.2f}% dev_CER={100*dev['cer']:.2f}% "
                      f"train_seconds={record['train_seconds']:.2f}", flush=True)
            else:
                print(f"epoch={epoch:03d} train_loss={record['train_loss']:.4f} "
                      f"train_seconds={record['train_seconds']:.2f}", flush=True)
            history.append(record)
            write_json(output / "status.json", {"status": "training", "epoch_completed": epoch,
                                               "epochs": config["epochs"], "latest": record})
            torch.save(checkpoint_payload(model, optimizer, epoch, config, data, history,
                                          best_key, best_epoch, scheduler), output / "last.pt")  # 调度器状态一起保存。
            write_json(output / "history.json", history)
            with (output / "history.csv").open("w", encoding="utf-8", newline="") as stream:
                fields = list(dict.fromkeys(key for row in history for key in row))
                writer = csv.DictWriter(stream, fieldnames=fields)
                writer.writeheader()
                writer.writerows(history)

    if not (output / "best.pt").is_file():
        raise RuntimeError("没有最佳模型可评测。请先训练至少一轮。")
    best = torch.load(output / "best.pt", map_location=device, weights_only=False)
    model.load_state_dict(best["model"])
    results, examples = {}, {}
    for split in ["train", "dev", "test"]:
        print(f"final evaluation: {split} ({len(data['splits'][split])} utterances)", flush=True)
        results[split], examples[split] = evaluate(model, data["splits"][split], data["vocab"], device, config, data)
        write_json(output / f"predictions_{split}.json", examples[split])
    summary = {"status": "completed", "selection": "lowest dev CER, then lowest dev loss",
               "best_epoch": best["epoch"], "epochs_recorded": len(history),
               "training_and_evaluation_seconds": time.perf_counter()-run_start,
               "environment": environment, "data_statistics": data["statistics"], "metrics": results,
               "evaluation": "greedy autoregressive decoding; no reference text is fed for predictions",
               "scope": (f"full AISHELL train/dev/test; {config.get('model_type', 'rnn')} teaching experiment" if config.get("require_complete")
                         else "filtered AISHELL subset; teaching experiment")}
    write_json(output / "summary.json", summary)
    write_report(output, summary, history, examples)
    write_json(output / "status.json", {"status": "completed", "best_epoch": best["epoch"]})
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    print(f"REPORT: {output / 'experiment_report.html'}", flush=True)


if __name__ == "__main__":
    main()

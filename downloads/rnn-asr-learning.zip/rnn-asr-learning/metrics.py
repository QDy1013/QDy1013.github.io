"""不依赖第三方评测包的字错误率。参考文字保留原字符，未知字符也算错误。"""


def edit_distance(reference: str, hypothesis: str) -> int:
    previous = list(range(len(hypothesis)+1))
    for i, a in enumerate(reference, 1):
        current = [i]
        for j, b in enumerate(hypothesis, 1):
            current.append(min(current[-1]+1, previous[j]+1, previous[j-1]+(a != b)))
        previous = current
    return previous[-1]


def summarize(rows: list[dict]) -> dict:
    errors = sum(row["edits"] for row in rows)
    chars = sum(len(row["reference"]) for row in rows)
    exact = sum(row["reference"] == row["prediction"] for row in rows)
    return {"utterances": len(rows), "errors": errors, "reference_characters": chars,
            "cer": errors/max(1, chars), "exact_utterances": exact,
            "exact_match_rate": exact/max(1, len(rows))}

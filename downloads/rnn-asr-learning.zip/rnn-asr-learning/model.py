# 阅读顺序：forward 看整体流程 → __init__ 看有哪些部件 → encode / decode 看两台 RNN → greedy_decode 看实际识别。
# self 表示当前这个模型对象；self.encoder、self.decoder 是保存在模型里的两个独立 RNN。
# config 从 config.json 读取。__init__ 搭建计算部件，训练时才会逐步更新这些部件的参数。
#
# 后面的注释用这些字母描述张量形状。张量可以先理解成一个能放在 CPU / GPU 上的多维数字数组：
# B：这批有几条语音；T：这批补齐后的声音帧数；F：每帧的 Fbank 维度，当前为 80。
# G：每 4 帧拼成一组后的组数；H：RNN 隐藏向量长度，当前为 192；K：RNN 层数，当前为 1。
# U：解码器这次处理的文字步数；E：一个文字 token 的嵌入维度，当前为 128。
# V：词表大小，即可预测的符号种类数；刚跑完的小实验 V=638，其中也包括特殊符号。
# [B, T, 80] 表示 B 条语音、每条 T 帧、每帧 80 个数字，不是把 B×T×80 个数当作一条向量。
#
"""普通 tanh RNN 编码器—解码器：固定长度状态，没有注意力、LSTM、GRU 或 CTC。"""  # 本文件的用途说明。
from __future__ import annotations  # 延迟处理类型提示；类型提示用来说明参数类型，不是网络计算。

import torch  # 导入 PyTorch，用它创建数字张量、执行计算并支持训练所需的自动求导。
from torch import nn  # nn 提供神经网络部件，例如 RNN、线性层和文字嵌入层。
from torch.nn import functional as F  # 给 functional 起别名 F；本文件会用它的 pad 补零函数。
from torch.nn.utils.rnn import pack_padded_sequence  # 按真实语音长度打包，避免 RNN 把补齐帧当成声音继续读。

from data import BOS, EOS, PAD  # 从 data.py 导入起始符、结束符、补齐符的整数编号，不是普通汉字。


class RNNEncoderDecoder(nn.Module):  # 定义整个模型；继承 nn.Module 后，PyTorch 才能统一管理这些网络部件和参数。
    def __init__(self, config: dict, vocab_size: int):  # 创建模型时执行；config 是配置字典，vocab_size 是词表大小。
        super().__init__()  # 先初始化 nn.Module，后面添加的层才能被正确登记和训练。
        self.stack = config["stack_frames"]  # 读取拼帧数量；当前为 4，即把相邻 4 个 Fbank 向量拼成一组。
        self.hidden_size = config["hidden_size"]  # 读取隐藏向量长度 H=192；这个数字不是汉字种类数。
        self.num_layers = config["num_layers"]  # 读取 RNN 层数 K=1；一层内部也会沿时间反复更新隐藏状态。

        self.input_projection = nn.Linear(  # 创建可训练的线性层：对每组声音特征重新加权组合。
            config["num_mel_bins"] * self.stack,  # 输入长度：80 维/帧 × 4 帧 = 320 个数字。
            self.hidden_size,  # 输出长度：192 个数字；它们将成为编码器每一步的输入。
        )  # 到这里完成部件定义；真正的投影计算发生在 encode 中。
        self.encoder = nn.RNN(  # 创建第一台普通 RNN，负责按顺序读声音；nn.RNN 内部已经实现了时间循环。
            self.hidden_size,  # 第一个参数是每步输入长度：192，而不是尚未整理过的 80 维 Fbank。
            self.hidden_size,  # 第二个参数是隐藏状态长度：每读一步，更新一个 192 维的记忆向量。
            num_layers=self.num_layers,  # 使用 1 层 RNN；多层时，各层分别维护自己的隐藏状态。
            nonlinearity="tanh", batch_first=True,  # tanh 是非线性变换；batch_first 表示输入按 [批次, 时间, 特征] 排列。
        )  # 这个 RNN 保存为 self.encoder，供 encode 调用。
        self.embedding = nn.Embedding(  # 创建文字查表层：把整数编号的 token 换成可训练的数字向量。
            vocab_size, config["embedding_size"], padding_idx=PAD,  # 当前是 638 个符号、每个 128 维；补齐符这一行不更新梯度。
        )  # 这是文字的嵌入表，接收文字编号；声音的 Fbank 不会经过这张表。
        self.decoder = nn.RNN(  # 创建第二台普通 RNN，负责根据声音信息和文字上下文逐步生成文字。
            config["embedding_size"] + self.hidden_size,  # 每步输入长度：前一个字的 128 维嵌入 + 固定 c 的 192 维 = 320。
            self.hidden_size,  # 解码器自己的隐藏状态长度也是 192，但它会在输出文字的过程中不断更新。
            num_layers=self.num_layers, nonlinearity="tanh", batch_first=True,  # 同样使用 1 层 tanh RNN，批次维放最前面。
        )  # 编码器和解码器是两个不同的对象，它们的可训练参数也各自独立。
        self.output_projection = nn.Linear(self.hidden_size, vocab_size)  # 把解码器的 192 维状态变成 V 个分数，每个符号一个分数。

    # encode 的输入已经是 data.py 算好并归一化的 Fbank；每条录音长度不同，所以还要传真实帧数 lengths。
    def encode(self, features: torch.Tensor, lengths: torch.Tensor):  # features 是 [B,T,80]；lengths 是 [B]，记录每条语音有几帧。
        batch, time, bins = features.shape  # 拆出数组的三个维度：B 条语音、补齐到 T 帧、每帧 F=80 维。
        pad = (-time) % self.stack  # 算出再补多少帧才能凑成 4 的倍数；例如 T=5 要补 3 帧，T=8 则补 0 帧。
        stacked = F.pad(features, (0, 0, 0, pad)).reshape(  # 先在时间末尾补零，再把相邻 4 帧归成一组。
            batch, -1, bins * self.stack,  # 变成 [B,G,320]；reshape 中的 -1 表示让 PyTorch 自动计算组数 G。
        )  # 只是把相邻帧的数字拼在一起，这一步本身不学习参数。

        # 一批录音会补到相同长度。尤其最后一组可能只有一两帧真实声音，其余位置必须清零。
        positions = torch.arange(  # 创建时间位置编号 0、1、2……，用于判断每条录音哪些帧是真实的。
            stacked.size(1) * self.stack, device=features.device,  # 一共有 G×4 个帧位置；device 保证编号与声音张量在同一设备上。
        )  # positions 的形状是 [G×4]。
        frame_mask = positions.unsqueeze(0) < lengths.to(features.device).unsqueeze(1)  # 比较位置和真实帧数，得到 [B,G×4] 的真/假表。
        stacked = stacked.reshape(batch, -1, self.stack, bins)  # 从 [B,G,320] 拆成 [B,G,4,80]，以便逐帧清理补齐位置。
        stacked = stacked * frame_mask.reshape(batch, -1, self.stack, 1)  # 真实帧乘 1，补齐帧乘 0；末尾的 1 让同一标记作用于 80 个特征。
        stacked = stacked.reshape(batch, -1, self.stack * bins)  # 再合回 [B,G,320]，让每组恢复成一个长向量。
        projected = torch.tanh(self.input_projection(stacked))  # 每组 320 维先线性变为 192 维，再经 tanh，得到 [B,G,192]。
        down_lengths = (lengths + self.stack - 1) // self.stack  # 每条语音的真实组数，按向上取整计算；例如 5 帧变成 2 组。
        packed = pack_padded_sequence(  # 打包时告诉 RNN 每条语音何时结束，使它跳过完整的补齐组。
            projected, down_lengths.cpu(), batch_first=True,  # 输入声音组和真实组数；这个打包接口要求长度数组放在 CPU。
            enforce_sorted=False,  # 允许这一批录音不按长度排序，打包函数会负责处理。
        )  # packed 仍承载声音特征，只是换成了适合不等长序列的包装形式。
        _, hidden = self.encoder(packed)  # RNN 从零初始状态读完整段声音；忽略逐步输出，只保留各层的最终状态 [K,B,192]。
        context = hidden[-1]  # 取最后一层的最终状态，得到 [B,192] 的 c；这里的 -1 指最后一层，hidden 本身已是最终时刻的状态。
        return context, hidden  # 返回固定声音信息 c，以及用来初始化解码器的各层状态；当前 K=1，二者包含同一份最终记忆。

    # c 在整次解码中固定；hidden 在第一次调用时来自编码器，后续调用时来自解码器上一步。
    def decode(self, previous_tokens, context, hidden):  # 接收前一个字的编号 [B,U]、固定声音向量 [B,192]、循环状态 [K,B,192]。
        embedded = self.embedding(previous_tokens)  # 文字编号查表，得到 [B,U,128]；神经网络后续计算使用这些数字，而非汉字字符串。
        repeated_context = context.unsqueeze(1).expand(  # 给 c 加上文字时间维，再让每个文字位置都能读取同一个 c。
            -1, embedded.size(1), -1,  # 得到 [B,U,192]；expand 中 -1 表示保持原维度，U 是这次要处理的文字步数。
        )  # 这里使用 expand 扩展视图，不是重新编码声音，也没有挑选某些声音帧。
        inputs = torch.cat([embedded, repeated_context], dim=-1)  # 在最后一维拼接文字与 c：128+192=320，得到 [B,U,320]。
        output, hidden = self.decoder(inputs, hidden)  # 解码器按顺序更新状态；output 是各步状态 [B,U,192]，hidden 是最后状态 [K,B,192]。
        return self.output_projection(output), hidden  # 将各步状态变成 [B,U,V] 的候选符号分数，同时返回更新后的隐藏状态。

    # 训练时，decoder_inputs 是右移后的正确文字。例如输入 [起始符,你,好]，要求分别预测 [你,好,结束符]。
    # 计算 loss、反向传播和更新参数在 train.py 中；forward 负责根据当前参数算出分数。
    def forward(self, features, lengths, decoder_inputs):  # 调用 model(...) 时 PyTorch 会进入这里；也用于验证阶段计算 loss。
        context, hidden = self.encode(features, lengths)  # 先读完整段声音，获得固定 c 与编码器最终状态。
        logits, _ = self.decode(decoder_inputs, context, hidden)  # 用已给定的文字前缀计算各步分数；这里不需要解码器最终状态，故用 _ 忽略。
        return logits  # 返回未经 softmax 的分数 [B,U,V]，交给交叉熵损失计算；此时还不是最终汉字。

    # 真正识别时，没有正确文字可用：先给起始符，再把模型自己刚选出的字送回去，继续预测下一个字。
    @torch.no_grad()  # 识别阶段不记录反向求导过程，节省内存；这行本身不会更新参数。
    def greedy_decode(self, features, lengths, max_steps=48):  # greedy 表示每一步只选最高分符号；最多生成 48 步，避免迟迟不结束。
        context, hidden = self.encode(features, lengths)  # 先编码声音；这个 context 在下面整个循环中始终不变。
        previous = torch.full(  # 为这一批每条语音准备第一个解码输入。
            (features.size(0), 1), BOS, device=features.device, dtype=torch.long,  # [B,1] 中全是起始符编号；long 是嵌入表需要的整数类型。
        )  # previous 是文字编号，不是隐藏向量；下一步会由 embedding 转成文字向量。
        finished = torch.zeros(  # 记录每条语音是否已经生成结束符，初始时都没有结束。
            features.size(0), device=features.device, dtype=torch.bool,  # 得到 [B] 的布尔数组，每个 False 对应一条还在识别的语音。
        )  # 同一批不同语音可以在不同步数结束。
        outputs = []  # 暂存每一步选出的符号编号；列表中的每个元素形状都是 [B]。
        for _ in range(max_steps):  # 最多循环 max_steps 次；_ 表示这里不用循环计数本身。
            logits, hidden = self.decode(previous, context, hidden)  # 用前一个字和固定 c 预测一步，同时把新的隐藏状态留给下一步。
            scores = logits[:, -1].clone()  # 取本次最后一个文字位置的 V 个分数，得到 [B,V]；复制后可安全屏蔽特殊符号。
            scores[:, PAD] = -torch.inf  # 把补齐符分数设成负无穷，确保不会把它当成识别文字选出来。
            scores[:, BOS] = -torch.inf  # 起始符只负责开始解码，也不允许被再次输出；结束符仍然可以被选中。
            token = scores.argmax(-1)  # 每条语音选择分数最高的符号编号，得到 [B]；它可能是一个字，也可能是结束符。
            token = torch.where(finished, torch.full_like(token, EOS), token)  # 已经结束的语音继续保持结束符，其余语音保留本步预测。
            outputs.append(token)  # 记录这一轮每条语音选出的符号编号。
            finished |= token.eq(EOS)  # 本步选中结束符就标记为结束；之前已经结束的标记也保留下来。
            previous = token.unsqueeze(1)  # [B] 变成 [B,1]，把本步预测当作下一步的“前一个字”。
            if finished.all():  # 如果这一批所有语音都已经生成结束符，就不需要继续循环。
                break  # 提前结束循环；尚未全结束时会继续到下一步或达到 48 步上限。
        return torch.stack(outputs, dim=1).cpu().tolist()  # 把各步拼成 [B,生成步数]，移回 CPU，再转成编号列表；data.py 再负责把编号还原成文字。

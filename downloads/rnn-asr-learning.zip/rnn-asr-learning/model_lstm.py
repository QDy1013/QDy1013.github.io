# 这是第二阶段：保持“声音编码 → 固定向量 → 逐字解码”，把两台普通 RNN 换成 LSTM。
# B 是一批语音数量，T 是声音帧数，H=192 是状态长度，K=1 是网络层数，U 是文字步数。
# LSTM 的状态是一对 (h, c)：h 是隐藏状态，c 是细胞状态；它们都会随时间更新。
# 本文件把固定语音向量叫 z，避免它与 LSTM 自己的细胞状态 c 混淆。
"""带中文逐行注释的 LSTM 编码器—解码器，固定向量，无注意力。"""  # 文件说明。
from __future__ import annotations  # 类型提示不影响网络计算。

import torch  # 提供张量、GPU 运算与自动求导。
from torch import nn  # 提供 LSTM、线性层和嵌入层。
from torch.nn import functional as F  # 用 F.pad 补齐声音帧。
from torch.nn.utils.rnn import pack_padded_sequence  # 让 LSTM 跳过补齐的声音位置。
from data import BOS, EOS, PAD  # 起始、结束、补齐三个特殊符号的编号。


class LSTMEncoderDecoder(nn.Module):  # 整个模型包含独立的 LSTM 编码器与解码器。
    def __init__(self, config: dict, vocab_size: int):  # 根据配置搭建部件；这里还没有开始训练。
        super().__init__()  # 初始化父类，让 PyTorch 管理模型参数。
        self.stack = config["stack_frames"]  # 相邻4帧拼成一组，减少循环步数。
        self.hidden_size = config["hidden_size"]  # h 和 c 每个状态向量的长度，当前为192。
        self.num_layers = config["num_layers"]  # 编码器和解码器各有1层 LSTM。
        self.input_projection = nn.Linear(config["num_mel_bins"] * self.stack, self.hidden_size)  # 每组320维声音转成192维。
        self.encoder = nn.LSTM(  # 第一台 LSTM：沿时间读取声音特征。
            self.hidden_size, self.hidden_size, num_layers=self.num_layers, batch_first=True,  # 输入192维，h和c也各192维。
        )  # 门控和细胞状态的更新公式已经由 nn.LSTM 实现。
        self.embedding = nn.Embedding(vocab_size, config["embedding_size"], padding_idx=PAD)  # 文字编号查成128维向量。
        self.decoder = nn.LSTM(  # 第二台 LSTM：根据声音信息和前一个字生成文字。
            config["embedding_size"] + self.hidden_size, self.hidden_size,  # 输入为128维文字向量加192维固定语音向量。
            num_layers=self.num_layers, batch_first=True,  # 每层都维护自己的 h 和 c；批次维排在最前面。
        )  # 两台 LSTM 参数不同，解码器不是再次调用编码器。
        self.output_projection = nn.Linear(self.hidden_size, vocab_size)  # 把192维解码状态变成每个候选符号的分数。

    def encode(self, features: torch.Tensor, lengths: torch.Tensor):  # 声音特征[B,T,80]与每条语音的真实帧数[B]。
        batch, time, bins = features.shape  # 取得批次数、补齐后的帧数、每帧维度。
        pad = (-time) % self.stack  # 计算还需要补多少帧，才能按4帧分组。
        stacked = F.pad(features, (0, 0, 0, pad)).reshape(batch, -1, bins * self.stack)  # 相邻4帧合为320维。
        positions = torch.arange(stacked.size(1) * self.stack, device=features.device)  # 建立声音帧的位置编号。
        frame_mask = positions.unsqueeze(0) < lengths.to(features.device).unsqueeze(1)  # 标出各条录音的真实帧。
        stacked = stacked.reshape(batch, -1, self.stack, bins)  # 拆出组内帧维度，以便处理最后不足4帧的组。
        stacked = stacked * frame_mask.reshape(batch, -1, self.stack, 1)  # 将补齐帧清零，防止它们污染声音表示。
        stacked = stacked.reshape(batch, -1, self.stack * bins)  # 重新变成每组320维的序列。
        projected = torch.tanh(self.input_projection(stacked))  # 线性投影后加非线性，得到[B,组数,192]。
        down_lengths = (lengths + self.stack - 1) // self.stack  # 计算每条录音真实包含多少组，向上取整。
        packed = pack_padded_sequence(projected, down_lengths.cpu(), batch_first=True, enforce_sorted=False)  # 跳过末尾补齐组。
        _, (h_n, c_n) = self.encoder(packed)  # 与普通RNN不同：LSTM返回最终h和最终c，各自形状[K,B,H]。
        context = h_n[-1]  # 取最后一层的最终h，作为固定语音向量z，形状[B,H]。
        state = (h_n, c_n)  # 同时保留两种状态，准备一起初始化解码器。
        return context, state  # z用于每个文字步；这对状态则由解码器不断更新。

    def decode(self, previous_tokens, context, state):  # 传入文字编号[B,U]、固定z[B,H]和状态(h,c)。
        embedded = self.embedding(previous_tokens)  # 将每个文字编号转成向量，得到[B,U,128]。
        repeated_context = context.unsqueeze(1).expand(-1, embedded.size(1), -1)  # 每个文字位置都读取同一份z。
        inputs = torch.cat([embedded, repeated_context], dim=-1)  # 文字128维与声音192维拼成320维。
        output, state = self.decoder(inputs, state)  # LSTM更新h和c，output是各文字步的隐藏状态。
        return self.output_projection(output), state  # 返回候选符号分数，以及更新后的(h,c)。

    def forward(self, features, lengths, decoder_inputs):  # 训练时由model(...)调用，接收右移后的正确文字。
        context, state = self.encode(features, lengths)  # 编码整段语音，获得固定z和编码器最终(h,c)。
        logits, _ = self.decode(decoder_inputs, context, state)  # 从正确文字前缀计算预测分数；梯度仍能传回编码器。
        return logits  # 返回[B,U,词表大小]，交给训练程序计算交叉熵。

    @torch.no_grad()  # 实际识别不记录梯度，也不更新参数。
    def greedy_decode(self, features, lengths, max_steps=64):  # 从起始符开始，每一步选择最高分符号。
        context, state = self.encode(features, lengths)  # 只读取声音，不把正确文字交给模型。
        previous = torch.full((features.size(0), 1), BOS, device=features.device, dtype=torch.long)  # 每条语音从起始符开始。
        finished = torch.zeros(features.size(0), device=features.device, dtype=torch.bool)  # 记录哪些语音已经输出结束符。
        outputs = []  # 保存每一步生成的文字编号。
        for _ in range(max_steps):  # 设置生成长度上限，避免模型迟迟不结束。
            logits, state = self.decode(previous, context, state)  # z保持固定，解码器的h和c持续更新。
            scores = logits[:, -1].clone()  # 每条语音取这一步的候选符号分数。
            scores[:, PAD] = -torch.inf  # 补齐符不能作为识别结果。
            scores[:, BOS] = -torch.inf  # 起始符不能在句子中重复生成。
            token = scores.argmax(-1)  # 选择每条语音当前得分最高的符号。
            token = torch.where(finished, torch.full_like(token, EOS), token)  # 已结束的语音保持结束。
            outputs.append(token)  # 保存当前生成结果。
            finished |= token.eq(EOS)  # 新生成结束符的语音也标记为结束。
            previous = token.unsqueeze(1)  # 把本步选出的字作为下一步输入。
            if finished.all():  # 这一批全部结束时可以提前退出。
                break  # 结束生成循环。
        return torch.stack(outputs, dim=1).cpu().tolist()  # 编号序列交给data.py转换为文字。

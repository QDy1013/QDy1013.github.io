# 普通 RNN 语音识别教学源码

从 WAV、Fbank 到固定向量编码器和解码器，再到训练、贪心识别与 CER。代码取自本次学习的桌面副本，保留中文注释。

## 先读哪些文件

1. `data.py`：清单、选样、Fbank、词表、归一化和 batch。
2. `model.py`：普通 RNN 编码器与解码器。
3. `train.py`、`training_steps.py`：训练、验证、检查点。
4. `predict.py`、`metrics.py`、`report.py`：单条识别、字错误率、报告。

`models.py` 在未指定 model_type 时选择 RNN。由于它会同时导入后续模型，四个后续模型文件也一并保留；它们不是普通 RNN 运行时的网络结构。本附件仅提供 RNN 的完整训练流程，其他模型的联合训练入口不在本附件的运行范围内。

## 环境

本次用已有 Python 3.12、PyTorch 2.11.0、torchaudio 2.11.0 环境验证 CPU 小流程。NumPy 也是运行依赖。torch 和 torchaudio 请使用匹配版本，并按照 PyTorch 官方安装方式选择 CPU 或适合自己显卡的版本：
https://pytorch.org/get-started/locally/

## 数据格式

自行准备 AISHELL 风格的 data/train、data/dev、data/test 目录，每个目录需要 wav.scp 和 text 两份 UTF-8 清单。wav.scp 每行“编号 音频文件路径”；text 每行“编号 正确文字”。音频需满足配置的采样率，并且是单声道 16-bit PCM WAV。脚本不下载语料，不自动重采样，不支持 wav.scp 中的管道命令。

样本的 speaker 使用音频父目录名，因此 train/dev/test 中的说话人目录名需要彼此不重叠。真实数据应保留原有按说话人划分，不要随便重排。

## 运行

以下命令从本目录运行。DATA_DIR 指向含 train/dev/test 的目录；输出目录使用本次实验自己的新目录。配置保留原实验路径，但 --data-dir 和 --output 会覆盖它们。

```bash
python test_core.py
python train.py --data-dir DATA_DIR --output runs/rnn_blog --prepare-only
python train.py --data-dir DATA_DIR --output runs/rnn_blog --epochs 10 --device cpu
python train.py --data-dir DATA_DIR --output runs/rnn_blog --epochs 60 --device cpu --resume
python predict.py runs/rnn_blog/best.pt AUDIO.wav
```

其中 DATA_DIR、AUDIO.wav 是需要替换的路径占位符。GPU 环境可将 --device cpu 改成 --device cuda。续训 --epochs 是希望达到的总轮数，不是额外增加的轮数。

`config.json` 默认选择 128/32/32 条数据并筛选短语音；实际数据不足时会报错。`config_full.json` 使用全量数据、磁盘缓存以及原机器的批次和读取进程设置。全量配置需要按自己的硬件调整，不建议直接作为第一次运行的配置。

`run_rnn.ps1` 是原实验的 WSL 启动器，包含原机器的环境与输出路径。公开学习时优先使用上面的 train.py 命令。

## 结果

输出目录中的 best.pt 按 dev CER、再按 dev loss 选优；last.pt 用于恢复训练。最终报告为 experiment_report.html。预测权重、音频和语料缓存不随源码提供。小型普通 RNN 的结构用于学习，不承诺可用识别率。

"""第五阶段：Transformer 编码器 + Transformer 注意力解码器 + CTC，与 LSTM 联合模型做结构对照。"""  # 教学模型，逐行中文注释。
from __future__ import annotations  # 允许在类型提示中直接写类型名称。

import math  # 计算位置编码的频率和缩放系数。
import torch  # 张量运算与自动求导。
from torch import nn  # Transformer层、线性层、嵌入层。
from torch.nn import functional as F  # 用F.pad补齐声音帧。
from data import BOS, EOS, PAD  # 特殊符号编号与其他实验相同。
from model_lstm_attention_ctc import collapse_ctc  # CTC贪心结果的“合并重复、删除blank”与LSTM版完全相同。


class PositionalEncoding(nn.Module):  # 自注意力本身不知道先后顺序，需要把“第几个位置”加进向量。
    def __init__(self, d_model: int, max_len: int = 4000):  # max_len要大于最长语音的声音位置数和最长文字数。
        super().__init__()  # 注册为PyTorch模块。
        position = torch.arange(max_len).unsqueeze(1)  # 位置编号0,1,2,...，形状[L,1]。
        frequency = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))  # 不同维度用不同频率（原论文公式）。
        table = torch.zeros(max_len, d_model)  # 位置编码表[L,D]。
        table[:, 0::2] = torch.sin(position * frequency)  # 偶数维用正弦。
        table[:, 1::2] = torch.cos(position * frequency)  # 奇数维用余弦。
        self.register_buffer("table", table, persistent=False)  # 固定的表，不是可学习参数，也不存进检查点。

    def forward(self, x):  # x为[B,T,D]。
        return x + self.table[: x.size(1)].unsqueeze(0)  # 每个位置加上自己的位置向量；batch内共用同一张表。


class JointCTCAttentionTransformer(nn.Module):  # 与JointCTCAttentionLSTM提供相同的接口，训练和评测代码可以直接复用。
    def __init__(self, config: dict, vocab_size: int):  # 搭建网络；从随机初始化开始。
        super().__init__()  # 让PyTorch管理各层参数。
        self.stack = config["stack_frames"]  # 与LSTM相同：相邻4帧拼成一个声音位置，时间分辨率40ms。
        self.d_model = config["d_model"]  # 每个位置的向量维度，例如128。
        dropout = config.get("dropout", 0.0)  # 所有dropout位置共用同一个比例。
        self.input_projection = nn.Linear(config["num_mel_bins"] * self.stack, self.d_model)  # 与LSTM相同的前端：320维拼接帧→d维。
        self.position = PositionalEncoding(self.d_model)  # 编码器和解码器共用同一张位置编码表。
        self.dropout = nn.Dropout(dropout)  # 输入和嵌入后的dropout。
        encoder_layer = nn.TransformerEncoderLayer(self.d_model, config["num_heads"], config["ffn_size"], dropout,  # 自注意力+前馈层，各自带残差连接。
                                                   batch_first=True, norm_first=True)  # 输入为[B,T,D]；先LayerNorm再计算（pre-norm），训练更稳。
        self.encoder = nn.TransformerEncoder(encoder_layer, config["encoder_layers"], norm=nn.LayerNorm(self.d_model),  # 堆叠多层编码器，最后再做一次LayerNorm。
                                             enable_nested_tensor=False)  # pre-norm下不能用嵌套张量加速，显式关闭以免警告。
        self.embedding = nn.Embedding(vocab_size, self.d_model, padding_idx=PAD)  # 把前一个字查成d维向量。
        decoder_layer = nn.TransformerDecoderLayer(self.d_model, config["num_heads"], config["ffn_size"], dropout,  # 带掩码的自注意力+读取声音的交叉注意力+前馈层。
                                                   batch_first=True, norm_first=True)  # 与编码器同样使用pre-norm。
        self.decoder = nn.TransformerDecoder(decoder_layer, config["decoder_layers"], norm=nn.LayerNorm(self.d_model))  # 堆叠多层解码器。
        self.output_projection = nn.Linear(self.d_model, vocab_size)  # Attention支路：预测下一个字。
        self.ctc_projection = nn.Linear(self.d_model, vocab_size - 2)  # CTC支路：与LSTM版相同，只含blank、UNK和普通字，不含BOS/EOS。

    def encode(self, features, lengths):  # features为[B,T,80]，lengths为每条语音真实帧数。
        batch, time, bins = features.shape  # B是语音数，T是补齐后的帧数。
        pad = (-time) % self.stack  # 补到能按4帧分组的长度。
        frames = F.pad(features, (0, 0, 0, pad))  # 只在时间维末尾补零。
        positions = torch.arange(frames.size(1), device=features.device)  # 原始帧位置编号。
        frame_mask = positions.unsqueeze(0) < lengths.to(features.device).unsqueeze(1)  # 标出真实存在的帧。
        frames = frames * frame_mask.unsqueeze(-1)  # 清除补齐帧，避免最后一组被无效值污染（与LSTM版相同）。
        stacked = frames.reshape(batch, -1, bins * self.stack)  # 每4个80维向量拼成320维。
        x = self.input_projection(stacked) * math.sqrt(self.d_model)  # 投影到d维，并按Transformer惯例放大，使其与位置编码的量级相称。
        x = self.dropout(self.position(x))  # 加上位置信息，再做dropout。
        down_lengths = (lengths + self.stack - 1) // self.stack  # 每条语音真正的声音位置数。
        valid = torch.arange(x.size(1), device=features.device).unsqueeze(0) < down_lengths.to(features.device).unsqueeze(1)  # True表示真实位置。
        memory = self.encoder(x, src_key_padding_mask=~valid)  # 自注意力只看真实位置；补齐位置不会被任何位置读取。
        return memory, valid, down_lengths  # memory[B,S,D]供解码器和CTC使用。

    def decode(self, previous_tokens, memory, valid):  # previous_tokens为[B,U]的文字前缀（以BOS开头）。
        length = previous_tokens.size(1)  # 文字步数U。
        causal = torch.triu(torch.ones(length, length, dtype=torch.bool, device=memory.device), 1)  # 上三角为True：第u步不能看到u之后的字，否则训练时等于偷看答案。
        y = self.embedding(previous_tokens) * math.sqrt(self.d_model)  # 字向量按惯例放大。
        y = self.dropout(self.position(y))  # 加位置信息，再dropout。
        hidden = self.decoder(y, memory, tgt_mask=causal,  # 带掩码的自注意力：只看已经出现的字。
                              tgt_key_padding_mask=previous_tokens.eq(PAD),  # 文字补齐位置不被读取。
                              memory_key_padding_mask=~valid)  # 交叉注意力只读取真实声音位置。
        return self.output_projection(hidden)  # 每个文字步对全部字符的分数[B,U,V]。

    def joint_forward(self, features, lengths, decoder_inputs):  # 训练和评测损失的统一入口，与LSTM版接口相同。
        memory, valid, down_lengths = self.encode(features, lengths)  # 声音只编码一次。
        attention_logits = self.decode(decoder_inputs, memory, valid)  # Attention支路：右移的正确文字作为输入（teacher forcing）。
        ctc_logits = self.ctc_projection(memory)  # CTC支路：每个声音位置预测字符或blank。
        return attention_logits, ctc_logits, down_lengths  # 长度与LSTM版一样留在CPU（CTC损失要求）；两种损失都反传到同一个编码器。

    def forward(self, features, lengths, decoder_inputs):  # 兼容只需要Attention分数的旧接口。
        return self.joint_forward(features, lengths, decoder_inputs)[0]  # 只返回Attention分数。

    @torch.no_grad()  # 识别时不保存梯度。
    def greedy_decode(self, features, lengths, max_steps=64):  # 实际识别只传声音，不传正确文字。
        memory, valid, _ = self.encode(features, lengths)  # 整段声音编码一次，之后每步重复读取。
        tokens = torch.full((features.size(0), 1), BOS, device=features.device, dtype=torch.long)  # 每条语音从起始符开始。
        finished = torch.zeros(features.size(0), device=features.device, dtype=torch.bool)  # 标记已经输出结束符的语音。
        outputs = []  # 保存每一步的输出。
        for _ in range(max_steps):  # 限制最长输出，避免无限生成。
            scores = self.decode(tokens, memory, valid)[:, -1].clone()  # 用目前已生成的全部前缀，取最后一步的分数。
            scores[:, PAD] = -torch.inf  # 不允许输出补齐符。
            scores[:, BOS] = -torch.inf  # 不允许在句中输出起始符。
            token = scores.argmax(-1)  # 每步选得分最高的字。
            token = torch.where(finished, torch.full_like(token, EOS), token)  # 已结束的语音保持EOS。
            outputs.append(token)  # 保存本步结果。
            finished |= token.eq(EOS)  # 新输出EOS的语音标记为结束。
            tokens = torch.cat([tokens, token.unsqueeze(1)], dim=1)  # 自己预测的字接到前缀后面，作为下一步输入。
            if finished.all():  # 全部结束则提前退出。
                break  # 结束解码。
        return torch.stack(outputs, dim=1).cpu().tolist()  # 返回编号序列，由统一评测程序计算CER。

    @torch.no_grad()  # 识别时不保存梯度。
    def ctc_greedy_decode(self, features, lengths):  # CTC识别只需要编码器。
        memory, _, down_lengths = self.encode(features, lengths)  # 共享编码器的输出。
        paths = self.ctc_projection(memory).argmax(-1).cpu().tolist()  # 每个声音位置选分数最高的候选。
        return collapse_ctc(paths, down_lengths.cpu().tolist())  # 合并重复、删除blank。

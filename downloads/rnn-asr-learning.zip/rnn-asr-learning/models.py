"""按配置选择教学模型；旧检查点未写model_type时默认普通RNN。"""
from model import RNNEncoderDecoder  # 第一阶段的普通RNN模型。
from model_lstm import LSTMEncoderDecoder  # 第二阶段的LSTM模型。
from model_lstm_attention import AttentionLSTMEncoderDecoder  # 第三阶段：每个文字步查询整段声音。
from model_lstm_attention_ctc import JointCTCAttentionLSTM  # 第四阶段：CTC和Attention共享编码器。
from model_transformer_ctc import JointCTCAttentionTransformer  # 第五阶段：Transformer结构对照。


def build_model(config, vocab_size):  # 根据配置创建一个全新模型，不自动读取其他模型的权重。
    kind = config.get("model_type", "rnn")  # 兼容此前已保存的RNN配置。
    choices = {"rnn": RNNEncoderDecoder, "lstm": LSTMEncoderDecoder,
               "lstm_attention": AttentionLSTMEncoderDecoder,
               "lstm_attention_ctc": JointCTCAttentionLSTM,
               "transformer_ctc": JointCTCAttentionTransformer}  # 五个模型使用相同数据和评测入口。
    if kind not in choices:  # 对未知类型直接报错，避免默默选错模型。
        raise ValueError(f"Unknown model_type: {kind}")  # 显示配置中的错误名称。
    return choices[kind](config, vocab_size)  # 创建并返回所选模型。

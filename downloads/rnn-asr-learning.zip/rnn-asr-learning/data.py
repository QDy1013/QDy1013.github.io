"""AISHELL、Fbank 和字符标签；支持小样本内存缓存与全量磁盘缓存。"""
from __future__ import annotations  # 延迟处理类型提示，让类型说明不必在函数定义时立即求值。

import hashlib  # 计算数据配置的 SHA-256 签名，用于判断缓存是否匹配。
import json  # 读写 JSON 格式的配置记录、词表和统计结果。
import random  # 按指定随机种子打乱样本编号，便于复现样本选择。
import wave  # 读取 WAV 音频，并检查采样率、声道数等信息。
import shutil  # 复制已有缓存中的词表和数据清单文件。
from pathlib import Path  # 导入 Path 类，用来拼接路径、检查文件和读写文本。

import numpy as np  # 导入 NumPy 并简写为 np；这里用它把音频字节解释为数字数组。
import torch  # 导入 PyTorch；这里用它创建张量、保存和读取特征等。
from torch.nn.utils.rnn import pad_sequence  # 导入补齐工具，将不同长度的序列补成同一长度。
from torch.utils.data import Dataset  # 导入数据集基类，供后面的 SpeechDataset 继承。
import torchaudio  # 导入音频工具包；这里用它从声音波形中提取 Fbank 特征。

# 词表中前四个编号留给特殊符号：补齐、开始、结束、词表外字符。
# 编号与 SPECIAL 中的位置一一对应，普通汉字从编号 4 开始。
PAD, BOS, EOS, UNK = 0, 1, 2, 3
SPECIAL = ["<pad>", "<bos>", "<eos>", "<unk>"]


# 第一步：读取清单。每行按第一次空白分成“语音编号”和“剩余内容”，
# 所以内容中的空格不会导致一行被拆成多个字段。返回 {编号: 路径或文字}。
def read_mapping(path: Path) -> dict[str, str]:
    result = {}  # 收集编号与内容的对应关系。
    for line in path.read_text(encoding="utf-8").splitlines():
        parts = line.split(maxsplit=1)  # 最多拆一次；空行或只有编号的行会被跳过。
        if len(parts) == 2:
            if parts[0] in result:
                raise ValueError(f"Duplicate utterance ID in {path}: {parts[0]}")
            result[parts[0]] = parts[1]
    return result


# 第二步：选择一个数据划分。split 是 train、dev 或 test；
# count 为 0 表示选择全部符合条件的样本，否则最多选指定数量。
def select_split(config: dict, split: str, count: int, seed: int) -> list[dict]:
    directory = Path(config["data_dir"]) / split
    if not (directory / "wav.scp").is_file():
        raise FileNotFoundError(f"找不到 {directory / 'wav.scp'}。请指定已有 AISHELL recipe 的 data 目录。")
    # 两份清单分别是“编号 -> 音频路径”和“编号 -> 正确文字”。
    paths = read_mapping(directory / "wav.scp")
    texts = read_mapping(directory / "text")
    if config.get("require_complete") and set(paths) != set(texts):
        raise ValueError(f"{split} 的音频与文字 ID 不完全对应，请检查数据准备。")
    # 只保留两份清单都有的编号；先排序再固定种子打乱，保证选择可复现。
    ids = sorted(set(paths) & set(texts))
    random.Random(seed).shuffle(ids)
    selected = []
    for uid in ids:
        text = "".join(texts[uid].split())  # 去掉文字中的空白，例如“你 好”变成“你好”。
        if not config["min_chars"] <= len(text) <= config["max_chars"]:
            continue
        path = Path(paths[uid])
        if not path.is_absolute():
            path = directory / path
        if not path.is_file():
            continue
        # 先检查 WAV 的采样率、声道、采样宽度和时长；此处还没有提取特征。
        with wave.open(str(path), "rb") as audio:
            rate = audio.getframerate()
            duration = audio.getnframes() / rate
            supported = audio.getnchannels() == 1 and audio.getsampwidth() == 2
        if rate != config["sample_rate"] or not supported:
            continue
        if not config["min_seconds"] <= duration <= config["max_seconds"]:
            continue
        # 把一条合格语音的元信息装进字典；speaker 使用音频父目录名。
        selected.append({"id": uid, "wav": str(path.resolve()), "text": text,
                         "seconds": duration, "speaker": path.parent.name})
        if count and len(selected) == count:
            return selected
    if count == 0 and selected:
        if config.get("require_complete") and len(selected) != len(ids):
            raise ValueError(f"{split} 需要全量有效数据，但只有 {len(selected)}/{len(ids)} 条通过格式、长度和文件检查。")
        print(f"selected {split}: {len(selected)}/{len(ids)} utterances", flush=True)
        return selected
    raise RuntimeError(f"{split} 符合条件的样本不足：期望 {count}，实际 {len(selected)}")


# 第三步：把一条 WAV 变成 Fbank 张量，形状通常是 [帧数, 频带数]。
# 例如 80 个频带意味着每个时间帧用 80 个数表示；帧数随录音长度变化。
def fbank_for_file(path: str, config: dict) -> torch.Tensor:
    """AISHELL 为 16 kHz、单声道、16-bit PCM，使用标准库读取，无新音频依赖。"""
    with wave.open(path, "rb") as audio:
        if audio.getframerate() != config["sample_rate"]:
            raise ValueError("音频采样率与配置不同；本教学版不会静默重采样。")
        if audio.getnchannels() != 1 or audio.getsampwidth() != 2:
            raise ValueError("本教学版要求单声道 16-bit PCM WAV。")
        # 将文件里的字节按小端 16 位有符号整数解释；copy 得到可独立使用的数组。
        pcm = np.frombuffer(audio.readframes(audio.getnframes()), dtype="<i2").copy()
    waveform = torch.from_numpy(pcm).float().unsqueeze(0)  # [采样点数] -> [1, 采样点数]，1 是单声道。
    # 按配置分帧并计算梅尔滤波器组特征；这里返回特征，不会训练模型。
    return torchaudio.compliance.kaldi.fbank(
        waveform, sample_frequency=config["sample_rate"],
        num_mel_bins=config["num_mel_bins"], frame_length=config["frame_length"],
        frame_shift=config["frame_shift"], dither=0.0, energy_floor=0.0,
    )


# 为影响数据选择和特征提取的配置生成签名，用于检查缓存能否复用。
def cache_signature(config: dict) -> str:
    keys = ["seed", "data_dir", "train_size", "dev_size", "test_size", "min_seconds",
            "max_seconds", "min_chars", "max_chars", "sample_rate", "num_mel_bins",
            "frame_length", "frame_shift"]
    source = {k: config[k] for k in keys}
    # 小实验的旧签名保持兼容；全量实验使用独立的磁盘缓存签名。
    if config.get("feature_storage", "memory") != "memory":
        source["feature_storage"] = config["feature_storage"]
    if config.get("require_complete"):
        source["require_complete"] = True
    return hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()


# 数据准备总入口：检查缓存 -> 选择样本 -> 建词表 -> 提取特征 -> 保存结果。
# 返回的 payload 包含词表、三个划分、训练集归一化统计和数据统计。
def prepare_dataset(config: dict, output_dir: Path) -> dict:
    # 如果指定共享缓存，检查签名后复用已有划分、词表、统计和特征。
    if config.get("shared_data_cache"):
        source = Path(config["shared_data_cache"]).resolve()
        if source == output_dir.resolve():
            raise ValueError("共享缓存来源与当前输出目录相同，请移除 shared_data_cache。")
        payload = torch.load(source / "data.pt", map_location="cpu", weights_only=False)
        if payload["signature"] != cache_signature(config):
            raise ValueError("共享缓存与本次数据配置不同，不能混用数据划分或词表。")
        # 共享实际特征文件与统计；只复制小型清单，避免重算或复制整份Fbank。
        for name in ["vocab.json", "data_statistics.json", "train.jsonl", "dev.jsonl", "test.jsonl"]:
            shutil.copy2(source / name, output_dir / name)
        (output_dir / "data_source.json").write_text(json.dumps({
            "source_cache": str(source / "data.pt"), "data_signature": payload["signature"],
            "shared": ["train/dev/test", "vocabulary", "training CMVN", "Fbank files"]}, indent=2), encoding="utf-8")
        print(f"Reusing existing data, vocabulary and Fbank cache: {source}", flush=True)
        return payload
    # 没有共享缓存时，先检查当前实验自己的数据缓存。
    cache = output_dir / "data.pt"
    signature = cache_signature(config)
    disk_features = config.get("feature_storage", "memory") == "disk"
    signature_file = output_dir / "preparation_signature.txt"
    if signature_file.is_file() and signature_file.read_text() != signature:
        raise ValueError("该目录已有不同设置的数据准备记录，请换一个输出目录。")
    if cache.is_file():
        payload = torch.load(cache, map_location="cpu", weights_only=False)
        if payload["signature"] != signature:
            raise ValueError("数据配置与现有缓存不同，请使用新的输出目录，保留旧实验。")
        return payload

    signature_file.write_text(signature)
    (output_dir / "status.json").write_text(json.dumps({"status": "preparing", "signature": signature}), encoding="utf-8")

    # 使用不同随机种子分别选择训练、验证、测试样本。
    splits = {name: select_split(config, name, config[f"{name}_size"], config["seed"] + i)
              for i, name in enumerate(["train", "dev", "test"])}
    # 检查划分之间没有重复语音编号或重复说话人。
    for a, b in [("train", "dev"), ("train", "test"), ("dev", "test")]:
        if {s["id"] for s in splits[a]} & {s["id"] for s in splits[b]}:
            raise ValueError("训练、验证与测试 utterance ID 重叠。")
        if {s["speaker"] for s in splits[a]} & {s["speaker"] for s in splits[b]}:
            raise ValueError("AISHELL 三个划分的说话人重叠，请检查数据目录。")

    # 只根据训练文字建立字符词表，避免使用验证和测试文字构建词表。
    vocab = SPECIAL + sorted({ch for sample in splits["train"] for ch in sample["text"]})
    stoi = {ch: i for i, ch in enumerate(vocab)}  # string-to-index：字符 -> 整数编号。
    # 累计训练集每个频带的总和、平方和及帧数，用来计算均值和标准差。
    feature_sum = torch.zeros(config["num_mel_bins"], dtype=torch.float64)
    feature_sumsq = torch.zeros_like(feature_sum)
    frame_count = 0
    stats = {}
    for split, samples in splits.items():
        if disk_features:
            (output_dir / "features" / split).mkdir(parents=True, exist_ok=True)
        unknown = 0
        characters = 0
        # 逐条处理，磁盘模式不会把全部特征同时保存在内存。
        for j, sample in enumerate(samples):
            if disk_features:
                # 每条只在首次使用时提取一次；中断后可复用已完成的文件。
                feature_path = output_dir / "features" / split / f"{sample['id']}.pt"
                if feature_path.is_file():
                    features = torch.load(feature_path, map_location="cpu", weights_only=True)
                else:
                    features = fbank_for_file(sample["wav"], config)
                    temporary = feature_path.with_suffix(".tmp")
                    torch.save(features, temporary)
                    temporary.replace(feature_path)
                sample["feature_path"] = str(feature_path)
            else:
                features = fbank_for_file(sample["wav"], config)
                sample["features"] = features
            # 把每个字转成词表编号；没见过的字用 UNK，不会直接删除。
            sample["tokens"] = [stoi.get(ch, UNK) for ch in sample["text"]]
            characters += len(sample["tokens"])
            unknown += sample["tokens"].count(UNK)
            # 归一化统计仅由训练集计算；验证、测试集不能参与统计。
            if split == "train":
                f = features.double()
                feature_sum += f.sum(0)
                feature_sumsq += f.square().sum(0)
                frame_count += f.size(0)
            if (j+1) % (1000 if disk_features else 32) == 0 or j+1 == len(samples):
                print(f"prepare {split}: {j+1}/{len(samples)}", flush=True)
                (output_dir / "status.json").write_text(json.dumps({
                    "status": "preparing", "split": split, "prepared": j+1,
                    "total": len(samples)}, ensure_ascii=False), encoding="utf-8")
        stats[split] = {"utterances": len(samples), "characters": characters,
                        "seconds": sum(s["seconds"] for s in samples),
                        "unknown_characters": unknown,
                        "unknown_rate": unknown / max(1, characters)}
    # 每个频带分别计算均值与标准差：方差 = 平方的均值 - 均值的平方。
    # clamp_min 防止数值误差或极小方差导致开方、除法不稳定。
    mean = (feature_sum / frame_count).float()
    variance = feature_sumsq / frame_count - (feature_sum/frame_count).square()
    std = variance.clamp_min(1e-5).sqrt().float()
    # 内存模式现在就归一化；磁盘模式保留原特征，在 __getitem__ 读取时归一化。
    if not disk_features:
        for samples in splits.values():
            for sample in samples:
                sample["features"] = (sample["features"] - mean) / std
    # 除完整缓存 data.pt 外，也输出方便人工查看的词表、清单和统计。
    payload = {"version": 2 if disk_features else 1, "signature": signature, "vocab": vocab, "splits": splits,
               "cmvn_mean": mean, "cmvn_std": std, "statistics": stats}
    (output_dir / "vocab.json").write_text(json.dumps(vocab, ensure_ascii=False, indent=2), encoding="utf-8")
    for split, samples in splits.items():
        plain = [{k: v for k, v in s.items() if k not in {"features", "tokens"}} for s in samples]
        (output_dir / f"{split}.jsonl").write_text(
            "\n".join(json.dumps(s, ensure_ascii=False) for s in plain)+"\n", encoding="utf-8")
    (output_dir / "data_statistics.json").write_text(
        json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary_cache = cache.with_suffix(".tmp")
    torch.save(payload, temporary_cache)
    temporary_cache.replace(cache)
    return payload


def spec_augment(features, setting):  # SpecAugment：在归一化后的[T,80]特征上随机遮挡频带和时间段。
    frames, bins = features.shape  # T是10ms原始帧数，bins是80个梅尔频带；此时尚未4帧拼接。
    masked = features.clone()  # 复制一份，绝不修改磁盘缓存载入的原张量。
    for _ in range(setting.get("num_f_mask", 2)):  # 频率遮挡条数，默认2条。
        width = int(torch.randint(0, setting.get("max_f", 10) + 1, ()))  # 每条宽0～max_f个频带；用torch随机数，各读取进程种子不同。
        start = int(torch.randint(0, bins - width + 1, ()))  # 随机起始频带，保证不越界。
        masked[:, start:start + width] = 0  # 置0即CMVN后的均值，相当于“这里没有信息”。
    limit = min(setting.get("max_t", 50), int(frames * setting.get("max_t_ratio", 0.2)))  # 时间遮挡不超过max_t帧，也不超过全长的一定比例，防止短语音被整段盖掉。
    for _ in range(setting.get("num_t_mask", 2)):  # 时间遮挡条数，默认2条。
        width = int(torch.randint(0, limit + 1, ()))  # 每条长0～limit帧。
        start = int(torch.randint(0, frames - width + 1, ()))  # 随机起始帧。
        masked[start:start + width, :] = 0  # 该时间段所有频带都置0。
    return masked  # 返回遮挡后的新特征；验证和测试集不会调用本函数。


# Dataset 负责按下标取出一条样本；DataLoader 会调用它组成批次。
class SpeechDataset(Dataset):
    def __init__(self, samples: list[dict], cmvn_mean=None, cmvn_std=None, augment=None):
        self.samples = samples
        self.mean, self.std = cmvn_mean, cmvn_std
        self.augment = augment  # SpecAugment设置；None表示不增强（验证、测试、训练探针和旧实验）。

    def __len__(self):
        return len(self.samples)  # 数据集中共有多少条样本。

    def __getitem__(self, index):
        sample = self.samples[index]
        if "features" in sample:  # 内存模式：特征已载入并完成归一化。
            return sample
        # 只把当前这条语音的特征载入内存，随后由 collate 拼成一批。
        features = torch.load(sample["feature_path"], map_location="cpu", weights_only=True)
        features = (features-self.mean) / self.std  # 先做CMVN归一化，遮挡值0才等于均值。
        if self.augment:  # 只有训练loader会传入设置。
            features = spec_augment(features, self.augment)  # 每次读取都重新随机，同一语音每轮遮挡位置不同。
        return {**sample, "features": features}  # 复制样本字段并加入本次读出的特征。


# 将多条长度不等的样本拼成一批。B 是批大小，T 是本批最长帧数，F 是频带数。
# pad_sequence 在较短序列末尾补齐；lengths 保留每条声音补齐前的真实长度。
def collate(samples: list[dict]) -> dict:
    features = pad_sequence([s["features"] for s in samples], batch_first=True)  # [B,T,F]。
    lengths = torch.tensor([s["features"].size(0) for s in samples], dtype=torch.long)  # [B]。
    # 训练时输入前一个正确字符；当前字符始终在目标一侧，避免把答案直接传给当前预测。
    # 例：文字“你好”，输入是 [BOS, 你, 好]，目标是 [你, 好, EOS]。
    # 短文字用 PAD 补到同一长度；后续损失计算会忽略 PAD。
    decoder_inputs = pad_sequence([torch.tensor([BOS]+s["tokens"]) for s in samples],
                                  batch_first=True, padding_value=PAD)
    targets = pad_sequence([torch.tensor(s["tokens"]+[EOS]) for s in samples],
                           batch_first=True, padding_value=PAD)
    # 声音已经合成 features；这里只保留识别评测所需的样本信息。
    # 避免把每条原始特征再次从读取进程传到主进程，减少共享内存与通信开销。
    metadata = [{k: v for k, v in sample.items() if k != "features"} for sample in samples]
    return {"features": features, "lengths": lengths, "decoder_inputs": decoder_inputs,
            "targets": targets, "samples": metadata}


def collate_sorted(samples: list[dict]) -> dict:  # 只调整同一个有效batch内部的顺序，不跨batch交换样本。
    ordered = sorted(samples, key=lambda sample: sample["features"].size(0), reverse=True)  # 相近长度的语音进入同一显存小块。
    return collate(ordered)  # 保持原来的标签、样本和特征一一对应。


# 把模型预测的编号还原成可阅读的文字：遇到 EOS 停止，跳过 PAD 和 BOS。
# UNK 显示为方框，以提示预测了词表外符号。
def ids_to_text(ids: list[int], vocab: list[str]) -> str:
    result = []
    for token in ids:
        if token == EOS:
            break
        if token in (PAD, BOS):
            continue
        result.append("□" if token == UNK else vocab[token])
    return "".join(result)

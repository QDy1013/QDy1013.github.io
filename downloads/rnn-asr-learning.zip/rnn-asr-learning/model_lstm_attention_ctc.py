"""第四阶段：共享同一个 LSTM 编码器，同时训练 Attention 和 CTC。"""  # 这是联合训练教学模型。
import torch  # 提供张量及无梯度识别接口。
from torch import nn  # CTC 输出使用一个线性层。
from model_lstm_attention import AttentionLSTMEncoderDecoder  # 复用已经学过的注意力模型。


def collapse_ctc(paths, lengths):  # 输入逐帧CTC编号，输出原词表的字符编号。
    outputs = []  # 保存每条语音的识别结果。
    for path, length in zip(paths, lengths):  # 每条语音只读取真实声音位置。
        result, previous = [], None  # previous记录上一帧，包含blank。
        for token in path[:int(length)]:  # 忽略末尾补齐的帧。
            if token != previous and token != 0:  # 先合并相邻重复，再删除blank；顺序不能反过来。
                result.append(token + 2)  # CTC字符1对应原词表UNK3，其余字符也加2还原。
            previous = token  # blank也要更新previous，才能保留被blank隔开的重复字。
        outputs.append(result)  # 完成一条语音。
    return outputs  # 可以直接交给原有ids_to_text转换为中文。


class JointCTCAttentionLSTM(AttentionLSTMEncoderDecoder):  # 原有编解码器全部保留并参与训练。
    def __init__(self, config, vocab_size):  # 搭建原网络和新增的CTC支路。
        super().__init__(config, vocab_size)  # 创建共享编码器及Attention解码器。
        self.ctc_projection = nn.Linear(self.hidden_size, vocab_size - 2)  # CTC只含blank、UNK和普通字，不含BOS/EOS。

    def joint_forward(self, features, lengths, decoder_inputs):  # 一次编码同时服务两条支路。
        memory, valid, state = self.encode(features, lengths)  # 得到每个声音位置的表示和最终循环状态。
        attention_logits, _, _ = self.decode(decoder_inputs, memory, valid, state)  # Attention根据文字前缀预测下一字。
        ctc_logits = self.ctc_projection(memory)  # CTC直接给每个声音位置预测字符或blank。
        input_lengths = (lengths + self.stack - 1) // self.stack  # 帧拼接后，每条语音真正具有的声音位置数。
        return attention_logits, ctc_logits, input_lengths  # 两种损失最终都反传到同一个编码器。

    @torch.no_grad()  # 实际识别无需保存梯度。
    def ctc_greedy_decode(self, features, lengths):  # CTC识别只需要声音，不需要参考文字或Attention解码器。
        memory, _, _ = self.encode(features, lengths)  # 使用同一个已经联合训练的编码器。
        paths = self.ctc_projection(memory).argmax(-1).cpu().tolist()  # 各声音位置选择分数最高的候选。
        sizes = ((lengths + self.stack - 1) // self.stack).cpu().tolist()  # 删除每条语音的补齐位置。
        return collapse_ctc(paths, sizes)  # 合并重复、删除blank，得到字符序列。

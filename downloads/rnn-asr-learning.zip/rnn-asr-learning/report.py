"""仅根据真实运行记录生成本地 HTML 报告，不预填任何训练结果。"""
import html
import json
from pathlib import Path


def chart(history):
    width, height = 900, 265
    left, top, right, bottom = 56, 20, 870, 218
    maximum = max([r["train_loss"] for r in history]+[0.1]) * 1.1
    max_epoch = max([r["epoch"] for r in history]+[1])
    points = " ".join(f"{left+(right-left)*r['epoch']/max_epoch:.1f},"
                      f"{bottom-(bottom-top)*r['train_loss']/maximum:.1f}" for r in history)
    lines = []
    for fraction in [0, .25, .5, .75, 1]:
        y = bottom-(bottom-top)*fraction
        lines.append(f'<line x1="{left}" y1="{y}" x2="{right}" y2="{y}" stroke="#dce4ed"/>'
                     f'<text x="46" y="{y+4}" text-anchor="end">{maximum*fraction:.1f}</text>')
    return (f'<svg viewBox="0 0 {width} {height}" role="img" aria-label="训练损失随轮数变化">'
            + ''.join(lines) + f'<polyline fill="none" stroke="#167d8d" stroke-width="3" points="{points}"/>'
            + f'<text x="{left}" y="250">0</text><text x="{right-50}" y="250">{max_epoch} epoch</text></svg>')


def write_report(output: Path, summary: dict, history: list, predictions: dict):
    e = html.escape
    rows = ''.join(f'<tr><td>{split}</td><td>{summary["metrics"][split]["utterances"]}</td>'
                   f'<td>{summary["metrics"][split]["cer"]*100:.2f}%</td>'
                   f'<td>{summary["metrics"][split]["exact_utterances"]}</td>'
                   f'<td>{summary["data_statistics"][split]["unknown_rate"]*100:.2f}%</td></tr>'
                   for split in ['train', 'dev', 'test'])
    examples = []
    for split in ['train', 'dev', 'test']:
        samples = ''.join(f'<tr><td>{e(r["id"])}</td><td>{e(r["reference"])}</td>'
                          f'<td>{e(r["prediction"]) or "（空输出）"}</td><td>{r["edits"]}</td></tr>'
                          for r in predictions[split][:12])
        examples.append(f'<h3>{split} 的前 12 条样例</h3><table><thead><tr><th>ID</th><th>正确文字</th>'
                        f'<th>模型独立识别</th><th>编辑错误数</th></tr></thead><tbody>{samples}</tbody></table>')
    config = json.loads((output/'config.json').read_text(encoding='utf-8'))
    kind = config.get("model_type", "rnn")
    joint = kind in {"lstm_attention_ctc", "transformer_ctc"}  # 两种联合模型都有CTC支路。
    attention = kind in {"lstm_attention", "lstm_attention_ctc", "transformer_ctc"}
    network = {"rnn": "普通 RNN", "lstm": "LSTM", "lstm_attention": "LSTM + 注意力", "lstm_attention_ctc": "LSTM + Attention + CTC",
               "transformer_ctc": "Transformer + Attention + CTC"}[kind]
    model_file = {"rnn": "model.py", "lstm": "model_lstm.py", "lstm_attention": "model_lstm_attention.py", "lstm_attention_ctc": "model_lstm_attention_ctc.py",
                  "transformer_ctc": "model_transformer_ctc.py"}[kind]
    context_name = "z" if kind != "rnn" else "c"
    state_note = ("LSTM 的循环状态是一对(h,c)，其中细胞状态c与本报告的固定语音向量z是不同概念。"
                  if kind != "rnn" else "")
    if attention:
        introduction = "编码器和解码器都使用 LSTM。编码器保留整段声音的输出，解码器在每个文字步通过全局注意力重新读取声音。"
        pipeline = "声音 → 80维 Fbank → 相邻4帧拼接 → LSTM编码器的整段输出 → 每个文字步的注意力加权读取 → LSTM解码器逐字输出"
        mechanism = "每个文字步用解码状态给有效声音位置打分，softmax 后加权求和。补齐位置权重为0，动态上下文与解码状态融合后预测字符。编码器最终(h,c)仍用于初始化解码器；本模型不使用上下文输入反馈、Transformer 或 CTC。"
        reading = f"先读 {model_file} 的 encode：这里保留了所有声音位置的输出。再读 attend：打分、屏蔽补齐位置、归一化、加权求和。最后比较 forward 和 greedy_decode：实际识别时不给正确文字。"
    else:
        introduction = f"编码器和解码器都使用{network}，通过固定长度的状态连接，没有注意力、Transformer 或 CTC。"
        pipeline = f"声音 → 80维 Fbank → 相邻4帧拼接 → {network}编码器 → 固定语音向量 {context_name} → {network}解码器 → 逐字输出"
        mechanism = f"解码器每一步读取的固定语音向量都相同。它不会回头选择某个声音位置，因此这里没有注意力。{state_note}"
        reading = f"先读 {model_file} 的 encode，查看它怎样取得编码器最后的状态。再读 decode，查看固定语音向量、前一个字和解码器状态怎样合作。最后看 train.py 中损失计算与 greedy_decode 的区别。"
    joint_details = ""
    if joint:
        body = "Transformer" if kind == "transformer_ctc" else "LSTM"  # 编码器和解码器的结构名称。
        introduction = f"共享{body}编码器，两条支路联合训练：Attention根据文字前缀读取声音，CTC直接在声音位置预测字符或blank。"
        pipeline = f"声音 → Fbank → 共享{body}编码器 ┬→ Attention + {body}解码器 → 逐字输出\n                                └→ CTC线性层 → 逐帧预测 → 合并重复并删除blank"
        mechanism = f"联合损失=(1−{config['ctc_weight']})×Attention交叉熵+{config['ctc_weight']}×CTC损失。两部分分别按有效目标数归一化；全部原模型参数和新增CTC层都参与训练。主CER使用Attention贪心解码；CTC贪心CER另列，没有联合束搜索或重打分。"
        reading = f"先看{model_file}的joint_forward，再看ctc_objective.py和training_steps_ctc.py。CTC不需要预先给每一帧标字，会对可行的单调对齐路径求和；它不是一种注意力。"
        ctc_rows = ''.join(f'<tr><td>{split}</td><td>{summary["metrics"][split]["ctc_cer"]*100:.2f}%</td></tr>' for split in ['train', 'dev', 'test'])
        joint_details = '<h2>CTC支路独立识别</h2><table><tr><th>划分</th><th>CTC贪心CER</th></tr>' + ctc_rows + '</table>' + ('<p>本实验从旧Attention最佳模型初始化，使用新的Adam；不属于从头训练的严格架构对照。新阶段轮次单独计数。</p>'
                       if config.get("warm_start_checkpoint") else
                       '<p>本实验从随机初始化开始训练，使用SpecAugment、dropout、label smoothing和warmup+Noam学习率调度，用于LSTM与Transformer的结构对照。</p>')
    data_scope = "完整 AISHELL 原始划分" if config.get("require_complete") else "AISHELL 小样本"
    scale_note = (f"这是{network}的教学实验；是否能识别新语音，需要依据实际 CER 判断。"
                  if config.get("require_complete") else "样本规模很小，不能用这里的结果代表完整语音识别能力。")
    env = summary['environment']
    progress_rows = ''.join(
        f'<tr><td>{r["epoch"]}</td><td>{r["train_loss"]:.4f}</td>'
        f'<td>{r["train_probe_cer"]*100:.2f}%</td><td>{r["dev_cer"]*100:.2f}%</td></tr>'
        for r in history if r.get('dev_cer') is not None)
    document = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>{network}语音编解码实验</title>
<style>body{{font:18px/1.75 "Microsoft YaHei",sans-serif;color:#223448;background:#f5f7fa;margin:0}}
main{{max-width:1050px;margin:32px auto;background:white;padding:36px 44px}}h1,h2,h3{{color:#192d43;line-height:1.4}}
h2{{margin-top:32px}}table{{border-collapse:collapse;width:100%;margin:18px 0;font-size:16px}}
th,td{{border:1px solid #d7e0e7;padding:10px;text-align:left;overflow-wrap:anywhere}}th{{background:#e9f4f4}}
pre{{white-space:pre-wrap;background:#f3f6f9;padding:18px;font-size:16px}}svg{{width:100%;font-size:13px}}
.small{{font-size:15px;color:#5a6b7c}}@media(max-width:700px){{main{{margin:0;padding:20px}}table{{font-size:14px}}}}</style>
<main><h1>{network}语音编解码实验</h1>
<p>这是一个使用{data_scope}的教学实验。{introduction}</p>
<pre>{pipeline}</pre>
<p>{mechanism}</p>
<h2>实际运行</h2><p>设备：{e(str(env['gpu'] or env['device']))}；参数量：{env['parameters']:,}；
词表大小：{env['vocab_size']}；最佳模型：第 {summary['best_epoch']} 轮；记录轮数：{summary['epochs_recorded']}。</p>
<p>模型按验证集 dev 的字错误率选优，测试集 test 仅用于最终评测。以下识别文字由模型逐字生成，没有把参考文字输入解码器。</p>
<table><thead><tr><th>数据划分</th><th>样本数</th><th>CER 越低越好</th><th>整句正确数</th><th>参考字中词表外比例</th></tr></thead>
<tbody>{rows}</tbody></table>
<p><b>先比较 train 和 dev/test。</b>训练集识别好而新语音差，说明可能主要记住了训练样本。若两边都差，需要检查训练是否充分，以及输入表示、优化设置和网络结构。{scale_note}</p>
<p>词表和特征归一化只使用训练样本。验证或测试中未出现过的字记作词表外；预测未知字显示为“□”，评测仍对照原始正确文字，不会把这些错误删掉。CER 可以超过 100%，例如模型插入了大量多余文字。</p>
{joint_details}<h2>训练损失</h2>{chart(history)}
<p>Attention损失使用teacher forcing：给前一个正确字，预测下一个字；联合模型还包含不使用文字前缀的CTC损失。损失下降本身不等于能独立识别，需同时看自由生成CER。</p>
<table><thead><tr><th>轮次</th><th>训练 loss</th><th>固定训练样本 CER</th><th>验证集 CER</th></tr></thead><tbody>{progress_rows}</tbody></table>
<p>上表的训练 CER 只针对固定的少量训练样本；页面顶部的 train CER 则使用全部训练样本。最终识别样例来自按验证集选出的最佳模型，可能与最后一轮不同。</p>
<h2>真正识别出的文字</h2>{''.join(examples)}
<h2>你接下来可以看哪些代码</h2>
<p>{reading}</p>
<pre>{e(json.dumps(config,ensure_ascii=False,indent=2))}</pre>
<p class="small">数据划分、训练记录、模型权重和所有识别样例都与本报告放在同一输出目录。当前报告由运行结果自动生成。</p></main></html>'''
    (output/'experiment_report.html').write_text(document, encoding='utf-8')

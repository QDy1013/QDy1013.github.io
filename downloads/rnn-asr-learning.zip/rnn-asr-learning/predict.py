"""加载自己的 best.pt，识别一条单声道 16 kHz PCM WAV。"""
import argparse
from pathlib import Path

import torch

from data import fbank_for_file, ids_to_text
from models import build_model


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("wav", type=Path)
    parser.add_argument("--decoder", choices=["attention", "ctc"], default="attention")
    args = parser.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    config = saved["config"]
    model = build_model(config, len(saved["vocab"])).to(device).eval()
    model.load_state_dict(saved["model"])
    features = fbank_for_file(str(args.wav), config)
    features = (features-saved["cmvn_mean"]) / saved["cmvn_std"]
    if args.decoder == "ctc":
        if not hasattr(model, "ctc_greedy_decode"):
            parser.error("该检查点没有CTC支路。")
        output = model.ctc_greedy_decode(features.unsqueeze(0).to(device), torch.tensor([features.size(0)]))
    else:
        output = model.greedy_decode(features.unsqueeze(0).to(device), torch.tensor([features.size(0)]),
                                     config["max_decode_steps"])
    print(ids_to_text(output[0], saved["vocab"]))


if __name__ == "__main__":
    main()

"""把一个有效batch拆成小块求梯度；所有小块完成后只更新一次参数。"""  # 不改变每次参数更新所用的总语音数。
import time  # 记录实际训练时间。
import torch  # 张量、梯度和CUDA计时。
from torch.nn import functional as F  # 交叉熵损失。
from data import PAD  # 补齐字符不参与损失。


def backward_effective_batch(model, batch, device, config, vocab_size):  # 此函数累积梯度，不清空梯度、不执行优化器更新。
    size = batch["features"].size(0)  # 当前有效batch的语音数；末批可能不足512。
    micro = min(config.get("micro_batch_size", size), size)  # 一次送入显卡的语音数，例如256。
    count = int(batch["targets"].ne(PAD).sum().item())  # 先在CPU上统计整个有效batch的真实目标字符数。
    if micro <= 0 or count == 0:  # 防止错误配置或空目标导致除零。
        raise ValueError("micro_batch_size和有效目标字符数必须为正。")  # 明确报告问题。
    non_blocking = config.get("pin_memory", False)  # 沿用原来的固定内存传输设置。
    profile = config.get("profile_steps", False) and device.type == "cuda"  # CUDA事件只在启用计时时创建。
    events = []  # 保存每个小块的传输、计算起止事件。
    parts = []  # 保存已分离计算图的损失标量，不保存大输出张量。
    for begin in range(0, size, micro):  # 512条会分成256+256；最后不足一块时也照常处理。
        end = min(begin + micro, size)  # 保证末块不会越界。
        if profile:  # 用CUDA事件测量异步GPU工作。
            transfer_start, transfer_end, backward_end = [torch.cuda.Event(enable_timing=True) for _ in range(3)]  # 三个边界。
            transfer_start.record()  # CPU到GPU复制开始。
        features = batch["features"][begin:end].to(device, non_blocking=non_blocking)  # 只把本小块声音放上显卡。
        inputs = batch["decoder_inputs"][begin:end].to(device, non_blocking=non_blocking)  # 本小块的正确文字前缀。
        targets = batch["targets"][begin:end].to(device, non_blocking=non_blocking)  # 本小块需要预测的文字。
        if profile:  # 数据复制与网络计算分开计时。
            transfer_end.record()  # 复制结束，前向计算将开始。
        logits = model(features, batch["lengths"][begin:end], inputs)  # 用相同网络计算当前小块。
        loss_sum = F.cross_entropy(logits.reshape(-1, vocab_size), targets.reshape(-1), ignore_index=PAD, reduction="sum")  # 累加有效字符损失。
        loss = loss_sum / count  # 除以整个512条的字符总数；不能分别取均值后简单除2。
        if not torch.isfinite(loss):  # 与原训练一样检查异常数值。
            raise RuntimeError("训练损失出现NaN/Inf，停止以免保存无效权重。")  # 不继续更新。
        loss.backward()  # 将本小块梯度加到已有梯度上，下一块继续累积。
        if profile:  # 反向结束；尚未执行参数更新。
            backward_end.record()  # GPU计算阶段的结束位置。
            events.append((transfer_start, transfer_end, backward_end))  # 稍后同步后读取耗时。
        parts.append(loss_sum.detach())  # 只保留一个标量供报告loss使用。
        del logits, loss, loss_sum, targets, inputs, features  # 及时释放本小块的大张量，再计算下一块。
    return torch.stack(parts).sum(), count, events  # 所有小块贡献合成整个有效batch的结果。


def train_step(model, optimizer, batch, device, config, vocab_size):  # 一个调用仍对应一次参数更新。
    if config.get("model_type") in {"lstm_attention_ctc", "transformer_ctc"}:  # 联合模型同时计算CTC和Attention两种损失。
        from training_steps_ctc import train_joint_step  # 原来的三种模型继续使用下方原公式。
        return train_joint_step(model, optimizer, batch, device, config, vocab_size)  # 有效batch与更新频率保持一致。
    began = time.perf_counter()  # 记录包含CPU操作的实际步骤耗时。
    optimizer.zero_grad(set_to_none=True)  # 仅在整个有效batch开始前清空一次梯度。
    loss_sum, count, events = backward_effective_batch(model, batch, device, config, vocab_size)  # 累积全部小块。
    torch.nn.utils.clip_grad_norm_(model.parameters(), config["grad_clip"])  # 累积完成后统一裁剪一次。
    optimizer.step()  # 512条全部处理完成，才统一更新一次Adam参数。
    if events:  # 记录裁剪和参数更新后的GPU事件。
        update_end = torch.cuda.Event(enable_timing=True)  # 更新阶段的结束标记。
        update_end.record()  # 标记放在与更新相同的默认CUDA流中。
    value = loss_sum.item()  # 与原实现一样读取loss；这也等待本步默认流上的更新完成。
    transfer = sum(start.elapsed_time(copied) for start, copied, _ in events) / 1000 if events else 0.0  # 各小块复制秒数。
    compute = sum(copied.elapsed_time(done) for _, copied, done in events) / 1000 if events else 0.0  # 前向与反向秒数。
    if events:  # 加上统一梯度裁剪和Adam更新的时间。
        compute += events[-1][-1].elapsed_time(update_end) / 1000  # 事件耗时已通过上面的item同步。
    return {"loss_sum": value, "tokens": count, "step_seconds": time.perf_counter()-began,
            "transfer_seconds": transfer, "gpu_compute_seconds": compute}  # 这些统计不参与梯度计算。

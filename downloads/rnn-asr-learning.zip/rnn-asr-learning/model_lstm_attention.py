"""第三阶段：LSTM 编解码器加全局注意力；每个文字步重新读取整段声音表示。"""  # 本模型用于与固定向量 LSTM 对照。
from __future__ import annotations  # 允许在类型提示中直接写类型名称。

import math  # 用平方根缩放注意力分数。
import torch  # 提供张量、矩阵乘法和自动求导。
from torch import nn  # 提供嵌入层、LSTM 和线性层。
from torch.nn import functional as F  # 用 F.pad 补齐声音帧。
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence  # 编码时跳过补齐，再还原整段输出。
from data import BOS, EOS, PAD  # 特殊符号的编号与其他实验相同。


class AttentionLSTMEncoderDecoder(nn.Module):  # 编码器和解码器仍然都是 LSTM。
    def __init__(self, config: dict, vocab_size: int):  # 搭建网络；此处不会读取旧模型权重。
        super().__init__()  # 让 PyTorch 管理各层参数。
        self.stack = config["stack_frames"]  # 相邻4帧合并，减少声音时间步数。
        self.hidden_size = config["hidden_size"]  # 每个声音位置和解码状态均为192维。
        self.num_layers = config["num_layers"]  # 保持与固定向量实验相同的 LSTM 层数。
        self.input_projection = nn.Linear(config["num_mel_bins"] * self.stack, self.hidden_size)  # 320维声音转成192维。
        self.encoder = nn.LSTM(self.hidden_size, self.hidden_size, num_layers=self.num_layers, batch_first=True)  # 读取声音序列。
        self.embedding = nn.Embedding(vocab_size, config["embedding_size"], padding_idx=PAD)  # 把前一个字查成128维向量。
        self.decoder = nn.LSTM(config["embedding_size"], self.hidden_size, num_layers=self.num_layers, batch_first=True)  # 根据文字前缀更新解码状态。
        self.query_projection = nn.Linear(self.hidden_size, self.hidden_size, bias=False)  # 学习解码状态如何查询声音位置。
        self.context_projection = nn.Linear(self.hidden_size * 2, self.hidden_size)  # 融合解码状态与本步读到的声音。
        self.output_projection = nn.Linear(self.hidden_size, vocab_size)  # 融合后预测下一个字。
        self.dropout = nn.Dropout(config.get("dropout", 0.0))  # 单层nn.LSTM自带的dropout参数不起作用，所以手动加；旧配置没有此项时为0，等于不做任何事。

    def encode(self, features, lengths):  # features 为[B,T,80]，lengths 为每条语音真实帧数。
        batch, time, bins = features.shape  # B是语音数量，T是补齐后的帧数。
        pad = (-time) % self.stack  # 补到能够按4帧分组的长度。
        frames = F.pad(features, (0, 0, 0, pad))  # 只在时间维末尾补零。
        positions = torch.arange(frames.size(1), device=features.device)  # 建立原始声音帧的位置编号。
        frame_mask = positions.unsqueeze(0) < lengths.to(features.device).unsqueeze(1)  # 标出每条语音真实存在的帧。
        frames = frames * frame_mask.unsqueeze(-1)  # 清除补齐帧，避免最后一组被无效值污染。
        stacked = frames.reshape(batch, -1, bins * self.stack)  # 每4个80维向量拼成一个320维向量。
        projected = torch.tanh(self.input_projection(stacked))  # 得到[B,声音组数,192]。
        down_lengths = (lengths + self.stack - 1) // self.stack  # 真实声音组数，向上取整。
        packed = pack_padded_sequence(projected, down_lengths.cpu(), batch_first=True, enforce_sorted=False)  # 编码器跳过末尾补齐。
        packed_outputs, state = self.encoder(packed)  # 保留每个声音位置的输出，以及最终(h,c)。
        memory, _ = pad_packed_sequence(packed_outputs, batch_first=True)  # memory[B,S,H]保存整段声音，而非只保留最后一个向量。
        memory = self.dropout(memory)  # 编码器输出dropout：Attention和CTC都读取它；eval()时自动关闭。
        valid = torch.arange(memory.size(1), device=features.device).unsqueeze(0) < down_lengths.to(features.device).unsqueeze(1)  # 注意力也必须跳过补齐位置。
        return memory, valid, state  # 整段输出供反复查询，最终(h,c)用于初始化解码器。

    def attend(self, queries, memory, valid):  # queries[B,U,H]是各文字步状态，memory[B,S,H]是声音序列。
        projected_queries = self.query_projection(queries)  # 学习把文字步状态变成声音查询向量。
        scores = torch.bmm(projected_queries, memory.transpose(1, 2)) / math.sqrt(self.hidden_size)  # 每个文字步与每个声音位置打分，得到[B,U,S]。
        scores = scores.masked_fill(~valid.unsqueeze(1), -torch.inf)  # 无效补齐位置的分数设为负无穷。
        weights = scores.softmax(dim=-1)  # 对声音位置归一化，每个文字步的有效权重之和为1。
        context = torch.bmm(weights, memory)  # 按权重读出声音，得到每个文字步自己的上下文[B,U,H]。
        return context, weights  # 同时保留权重，便于之后画对齐热力图。

    def decode(self, previous_tokens, memory, valid, state):  # 输入前面的字、整段声音及上一解码状态。
        embedded = self.dropout(self.embedding(previous_tokens))  # 文字编号变成向量[B,U,128]；dropout防止死记“前一个字是X就输出Y”。
        queries, state = self.decoder(embedded, state)  # 产生每个文字步的查询状态；h和c继续更新。
        context, weights = self.attend(queries, memory, valid)  # 每个文字步重新为声音位置分配权重。
        fused = torch.tanh(self.context_projection(torch.cat([queries, context], dim=-1)))  # 将文字状态与动态声音信息融合。
        logits = self.output_projection(self.dropout(fused))  # 输出层前再做一次dropout，然后预测各个候选字符的分数[B,U,V]。
        return logits, state, weights  # 返回分数、循环状态和注意力权重。

    def forward(self, features, lengths, decoder_inputs):  # 训练时使用右移后的正确文字作为输入。
        memory, valid, state = self.encode(features, lengths)  # 整段声音只编码一次。
        logits, _, _ = self.decode(decoder_inputs, memory, valid, state)  # 训练时可以一次计算所有文字步的注意力。
        return logits  # 与原实验使用相同的交叉熵训练接口。

    @torch.no_grad()  # 识别时不保存梯度，也不更新参数。
    def greedy_decode(self, features, lengths, max_steps=64):  # 实际识别只传声音，不传正确文字。
        memory, valid, state = self.encode(features, lengths)  # 保存整段声音供每个文字步读取。
        previous = torch.full((features.size(0), 1), BOS, device=features.device, dtype=torch.long)  # 每条语音从起始符开始。
        finished = torch.zeros(features.size(0), device=features.device, dtype=torch.bool)  # 标记已经生成结束符的语音。
        outputs = []  # 保存各步输出的字符编号。
        for _ in range(max_steps):  # 限制生成长度，避免无限输出。
            logits, state, _ = self.decode(previous, memory, valid, state)  # 根据自己上一字和动态声音上下文继续识别。
            scores = logits[:, -1].clone()  # 取得当前文字步的分数。
            scores[:, PAD] = -torch.inf  # 不允许识别结果包含补齐符。
            scores[:, BOS] = -torch.inf  # 不允许在句子中重复起始符。
            token = scores.argmax(-1)  # 每一步选择得分最高的字符。
            token = torch.where(finished, torch.full_like(token, EOS), token)  # 已结束的语音维持结束状态。
            outputs.append(token)  # 保存这一步的预测。
            finished |= token.eq(EOS)  # 新生成结束符的语音也记为结束。
            previous = token.unsqueeze(1)  # 自己预测的字成为下一步输入。
            if finished.all():  # 所有语音均结束时提前退出。
                break  # 结束解码循环。
        return torch.stack(outputs, dim=1).cpu().tolist()  # 返回编号序列，由统一评测程序计算 CER。
